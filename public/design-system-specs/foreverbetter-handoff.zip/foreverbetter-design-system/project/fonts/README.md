# Fonts

The marketing site uses **Fraunces + DM Sans + DM Mono** and the product/dashboard uses **Plus Jakarta Sans + JetBrains Mono**. All five families are loaded by `colors_and_type.css` directly from Google Fonts:

```
https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300..900
&family=DM+Sans:opsz,wght@9..40,300..700
&family=DM+Mono:wght@400;500
&family=Plus+Jakarta+Sans:wght@400;500;600;700;800
&family=JetBrains+Mono:wght@400;500;600
&display=swap
```

## Local files

None copied to this folder yet. If you want offline copies (for embedding in standalone HTML or PPTX export), you can either:

1. Download the variable-font `.woff2` files from [fonts.google.com](https://fonts.google.com/) and drop them here, then point `@font-face` rules at them.
2. Use the Google Fonts CDN at runtime — what `colors_and_type.css` already does.

**Flag:** If the user has license-clean local files (preferred for production), please drop them in this folder and I'll wire up `@font-face` to use them in place of the CDN.
