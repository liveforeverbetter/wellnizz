/* global React */
const { useState } = React;

const COLORS = {
  brand: "#df1e39", brandSoft: "#fce8eb", brandTint: "#fdf3f5",
  canvas: "#f6f3ee", paper: "#fbf9f5", ink: "#0e0e0e",
  inkSoft: "#3a3a38", inkMute: "#7a7770", line: "#e6e1d8",
  lineSoft: "#efeae0", good: "#1e7a52", night: "#0a0806",
};
const FONTS = {
  display: '"Fraunces", "Georgia", serif',
  sans:    '"DM Sans", system-ui, sans-serif',
  mono:    '"DM Mono", ui-monospace, monospace',
};

function Logo({ light = false }) {
  const fg = light ? "#fff" : COLORS.ink;
  return (
    <span style={{
      fontFamily: '"DM Sans", system-ui, sans-serif',
      fontSize: 20, fontWeight: 700, color: fg, letterSpacing: "-0.025em",
      lineHeight: 1, whiteSpace: "nowrap",
    }}>
      forever<span style={{ color: COLORS.brand }}>better</span>
    </span>
  );
}

function Btn({ children, onClick, variant = "primary", full = false, href }) {
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    minHeight: 48, width: full ? "100%" : undefined,
    border: "1.5px solid transparent", borderRadius: 999,
    padding: "0 24px", fontFamily: FONTS.sans, fontSize: 14, fontWeight: 600,
    textDecoration: "none", whiteSpace: "nowrap", cursor: "pointer", letterSpacing: 0.2,
  };
  const variants = {
    primary: { background: COLORS.brand, borderColor: COLORS.brand, color: "#fff" },
    dark:    { background: COLORS.ink,   borderColor: COLORS.ink,   color: "#fff" },
    ghost:   { background: "transparent", borderColor: COLORS.ink,  color: COLORS.ink },
    glass:   {
      background: "rgba(255,255,255,0.12)", borderColor: "rgba(255,255,255,0.28)",
      color: "#fff", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)",
    },
  };
  const Tag = href ? "a" : "button";
  return <Tag href={href} onClick={onClick} style={{ ...base, ...variants[variant] }}>{children}</Tag>;
}

function Eyebrow({ children, light = false }) {
  return (
    <div style={{
      fontFamily: FONTS.mono, fontSize: 11,
      color: light ? "rgba(255,255,255,0.5)" : COLORS.inkMute,
      letterSpacing: 2, textTransform: "uppercase",
    }}>{children}</div>
  );
}

function Stat({ value, label, light = false }) {
  return (
    <div>
      <div style={{ fontFamily: FONTS.display, fontSize: 28, fontWeight: 700, color: light ? "#fff" : COLORS.ink, lineHeight: 1 }}>{value}</div>
      <div style={{ fontFamily: FONTS.mono, fontSize: 10, color: light ? "rgba(255,255,255,0.5)" : COLORS.inkMute, letterSpacing: 1, textTransform: "uppercase", marginTop: 4 }}>{label}</div>
    </div>
  );
}

function Check() {
  return (
    <span style={{
      display: "inline-grid", placeItems: "center",
      width: 22, height: 22, borderRadius: 999,
      background: COLORS.brand, color: "#fff", flexShrink: 0, fontSize: 11, fontWeight: 700,
    }}>+</span>
  );
}

Object.assign(window, { COLORS, FONTS, Logo, Btn, Eyebrow, Stat, Check, useState });
