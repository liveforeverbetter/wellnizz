/* global React, COLORS, FONTS */

function DashboardCard() {
  const rows = [
    { code: "LDL-C", label: "Cholesterol", value: "92 mg/dL", st: true },
    { code: "HBA1C", label: "Glycemic",    value: "5.2%",     st: true },
    { code: "APOB",  label: "ApoB",        value: "118 mg/dL", st: false },
    { code: "HSCRP", label: "Inflammation", value: "2.8 mg/L", st: null },
    { code: "VITD",  label: "Vitamin D",   value: "47 ng/mL", st: true },
  ];
  return (
    <div style={{
      background: "#111", border: "1px solid rgba(255,255,255,0.09)",
      borderRadius: 16, padding: 28, boxShadow: "0 24px 72px rgba(10,8,6,.22)",
      color: "#fff", width: "100%", maxWidth: 420,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <div style={{ fontFamily: FONTS.mono, fontSize: 10, color: "#a8a59c", letterSpacing: 1.4, textTransform: "uppercase" }}>Healthspan score</div>
          <div style={{ fontFamily: FONTS.display, fontSize: 72, fontWeight: 700, lineHeight: 1, marginTop: 4 }}>74</div>
        </div>
        <div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 48, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 4 }}>
            {[62, 58, 65, 68, 72, 71, 74].map((h, i) => (
              <span key={i} style={{
                width: 10, height: `${h}%`,
                background: i === 6 ? COLORS.brand : "rgba(255,255,255,0.18)",
                borderRadius: "3px 3px 0 0", display: "block",
              }} />
            ))}
          </div>
          <div style={{ fontFamily: FONTS.mono, fontSize: 9, color: COLORS.brand, letterSpacing: 1, marginTop: 6, textAlign: "right" }}>+6 vs. 2025 baseline</div>
        </div>
      </div>
      <div style={{ height: 1, background: "rgba(255,255,255,0.07)", marginBottom: 16 }} />
      {rows.map(({ code, label, value, st }, i) => (
        <div key={code} style={{
          display: "grid", gridTemplateColumns: "52px 1fr auto 10px",
          gap: 10, padding: "9px 0",
          borderTop: i === 0 ? "none" : "1px solid rgba(255,255,255,0.06)",
          alignItems: "center",
        }}>
          <span style={{ fontFamily: FONTS.mono, fontSize: 9, color: "#a8a59c", letterSpacing: 1.2, textTransform: "uppercase" }}>{code}</span>
          <span style={{ fontFamily: FONTS.sans, fontSize: 13, color: "rgba(255,255,255,0.82)" }}>{label}</span>
          <span style={{ fontFamily: FONTS.mono, fontSize: 12, color: "#fff" }}>{value}</span>
          {st === null
            ? <span style={{ width: 8, height: 8, borderRadius: 999, background: "#c98a1d", display: "inline-block" }} />
            : <span style={{ width: 8, height: 8, borderRadius: 999, background: st ? COLORS.good : COLORS.brand, display: "inline-block" }} />
          }
        </div>
      ))}
      <div style={{
        marginTop: 16,
        background: "linear-gradient(135deg, rgba(223,30,57,0.18) 0%, rgba(223,30,57,0.06) 100%)",
        border: "1px solid rgba(223,30,57,0.28)", borderRadius: 10,
        padding: "12px 16px", display: "flex", alignItems: "center", gap: 12,
      }}>
        <div style={{ width: 6, height: 6, borderRadius: 999, background: COLORS.brand, flexShrink: 0 }} />
        <div>
          <div style={{ fontFamily: FONTS.mono, fontSize: 10, color: COLORS.brand, letterSpacing: 0.8, textTransform: "uppercase" }}>Top action</div>
          <div style={{ fontFamily: FONTS.sans, fontSize: 13, color: "rgba(255,255,255,0.88)", marginTop: 2 }}>Lower ApoB — nutrition first</div>
        </div>
      </div>
    </div>
  );
}

window.DashboardCard = DashboardCard;
