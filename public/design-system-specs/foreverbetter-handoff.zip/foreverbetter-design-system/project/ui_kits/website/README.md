# foreverbetter — Marketing website UI kit

A high-fidelity recreation of the public marketing site (`foreverbetter.com`) homepage. Source of truth: `website/src/app/page.tsx` (current redesign) + `website/src/app/layout.tsx` + `website/tokens.css`.

## What's here

- `index.html` — clickable homepage (sticky nav, hero with dashboard mockup, steps, biomarker bento, pricing block, FAQ, footer). Clicking `Become a Member` opens a fake checkout sheet.
- `components.jsx` — small reusable bits (`Logo`, `Btn`, `Eyebrow`, `Stat`, `Check`).
- `sections-panel.jsx` — page sections (`Nav`, `Hero`, `Steps`, `Bento`, `Pricing`, `Faq`, `Footer`, `CheckoutSheet`).
- `dashboard-card.jsx` — the dark dashboard mock that sits in the hero (live React, not a screenshot).

## Visual language

- Font stack: Fraunces + DM Sans + DM Mono.
- Brand: coral red `#df1e39`; canvas `#f6f3ee`; ink `#0e0e0e`.
- Pill nav (`radius-full`), giant numeric prefixes for steps, hairline dividers, dark inverted pricing section with liquid-glass card.

## Coverage

Component | Status
--- | ---
Sticky pill nav | ✅
Hero (split, photo bg, dark gradient, dashboard mockup) | ✅
Trust strip | ✅
Steps (alternating photo / copy) | ✅ (numeric prefix row + 1 photo row demo)
Biomarker bento (3×3 + WGS row) | ✅
Pricing block (dark, liquid-glass card) | ✅
FAQ accordion | ✅
Footer w/ medical disclaimer | ✅
Checkout flow | partial (modal sheet)

Pages other than the homepage (`/what-we-test`, `/checkout/CheckoutFlow`, etc.) are not recreated — the homepage covers the visual vocabulary already.
