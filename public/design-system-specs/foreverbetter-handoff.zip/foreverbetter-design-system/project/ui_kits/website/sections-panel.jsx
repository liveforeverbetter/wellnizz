/* global React, COLORS, FONTS, Logo, Btn, Eyebrow, Stat, Check, DashboardCard, useState */

const CONTENT_FRAME = { maxWidth: 1440, margin: "0 auto" };
const SECTION_PAD = { padding: "clamp(80px,10vw,128px) clamp(20px,5vw,64px)" };
const H2 = {
  fontFamily: FONTS.display, fontSize: "clamp(40px,5vw,64px)",
  fontWeight: 700, lineHeight: 1.05, letterSpacing: -1, margin: 0, color: COLORS.ink,
};

// ─── Nav ─────────────────────────────────────────────────────────────
function Nav({ onCheckout }) {
  const links = [["What we test", "#what-we-test"], ["How it works", "#how-it-works"], ["Pricing", "#membership"], ["FAQ", "#faq"]];
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 50,
      display: "flex", alignItems: "center", justifyContent: "space-between",
      gap: 24, padding: "0 clamp(20px,4vw,56px)", height: 68,
      background: "rgba(246,243,238,0.90)",
      backdropFilter: "blur(20px) saturate(160%)",
      WebkitBackdropFilter: "blur(20px) saturate(160%)",
      borderBottom: `1px solid ${COLORS.line}`,
    }}>
      <Logo />
      <div style={{ display: "flex", gap: 32, fontSize: 14, fontWeight: 500 }}>
        {links.map(([label, href]) => (
          <a key={label} href={href} style={{ color: COLORS.inkSoft, textDecoration: "none" }}>{label}</a>
        ))}
      </div>
      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <a style={{ fontSize: 14, color: COLORS.inkMute, textDecoration: "none" }}>Sign in</a>
        <Btn variant="dark" onClick={onCheckout}>Become a Member</Btn>
      </div>
    </nav>
  );
}

// ─── Hero ────────────────────────────────────────────────────────────
function Hero({ onCheckout }) {
  return (
    <section style={{ position: "relative", minHeight: "100dvh", overflow: "hidden", background: COLORS.night }}>
      {/* photo bg — a deliberately muted golden gradient placeholder so the prototype works offline */}
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(135deg, #2a1f1a 0%, #4a3328 35%, #6d4b35 70%, #2a1f1a 100%)",
      }} />
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(100deg, rgba(10,8,6,0.88) 0%, rgba(10,8,6,0.70) 48%, rgba(10,8,6,0.48) 100%)",
      }} />
      <div style={{
        position: "relative", zIndex: 1, ...CONTENT_FRAME,
        minHeight: "100dvh",
        padding: "clamp(80px,10vw,120px) clamp(20px,5vw,64px) clamp(64px,8vw,96px)",
        display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 460px), 1fr))",
        gap: 64, alignItems: "center",
      }}>
        <div>
          <Eyebrow light>Europe's longevity membership</Eyebrow>
          <h1 style={{
            fontFamily: FONTS.display,
            fontSize: "clamp(40px,4.5vw,58px)", fontWeight: 700,
            lineHeight: 1.08, letterSpacing: -1, color: "#fff", margin: "20px 0 24px",
          }}>
            Know what your<br />biology is doing,<br />
            <span style={{ color: COLORS.brand }}>every year.</span>
          </h1>
          <p style={{ fontSize: 18, lineHeight: 1.6, color: "rgba(255,255,255,0.72)", maxWidth: 460, margin: "0 0 36px" }}>
            Annual longevity blood testing for Europe. 100+ biomarkers in a private EU-hosted dashboard with a protocol you can act on.
          </p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 48 }}>
            <Btn variant="primary" onClick={onCheckout}>Become a Member</Btn>
            <Btn variant="glass" href="#how-it-works">See how it works</Btn>
          </div>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(3, auto)",
            borderTop: "1px solid rgba(255,255,255,0.14)", paddingTop: 24, width: "fit-content",
          }}>
            {[["100+", "Biomarkers"], ["EUR 199", "Per year"], ["EU", "Data hosted"]].map(([s, l], i) => (
              <div key={l} style={{
                paddingRight: i < 2 ? 32 : 0, paddingLeft: i > 0 ? 32 : 0,
                borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.14)" : "none",
              }}>
                <Stat value={s} label={l} light />
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
          <DashboardCard />
        </div>
      </div>
    </section>
  );
}

// ─── Trust strip ─────────────────────────────────────────────────────
function TrustStrip() {
  return (
    <section style={{ background: "#111", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
      <div style={{
        ...CONTENT_FRAME, padding: "32px clamp(20px,5vw,64px)",
        display: "flex", justifyContent: "space-between", alignItems: "center", gap: 24, flexWrap: "wrap",
      }}>
        <Eyebrow light>Built on peer-reviewed science</Eyebrow>
        {["ClinVar / NCBI", "CPIC Guidelines", "Lopez-Otin Hallmarks", "ESC 2024", "GDPR Art. 9"].map((item) => (
          <span key={item} style={{
            fontFamily: FONTS.display, fontSize: 18, fontWeight: 600,
            color: "rgba(255,255,255,0.48)", whiteSpace: "nowrap",
          }}>{item}</span>
        ))}
      </div>
    </section>
  );
}

// ─── Steps ───────────────────────────────────────────────────────────
const STEPS = [
  { n: "01", tag: "30 minutes", title: "Take the test", body: "One fasted morning draw at a partner lab. We send the prep checklist, order form, and exact instructions before you arrive." },
  { n: "02", tag: "5–7 days",   title: "Get your results", body: "Results are normalised, scored, and loaded into your private EU-hosted dashboard with explanations, trends, and raw data export." },
  { n: "03", tag: "Live call",  title: "Review the signal", body: "A direct walkthrough of your findings before you change anything. What matters, what to watch, and what to escalate to a physician." },
  { n: "04", tag: "Ongoing",    title: "Act on your plan",  body: "Four to six ranked actions across nutrition, training, supplements, and physician follow-up. Retest yearly and track the trajectory." },
];

function Steps() {
  return (
    <section id="how-it-works" style={{ background: COLORS.canvas }}>
      <div style={{ ...CONTENT_FRAME, padding: "clamp(72px,9vw,112px) clamp(20px,5vw,64px) clamp(48px,5vw,64px)" }}>
        <h2 style={{ ...H2, fontSize: "clamp(44px,5.5vw,72px)" }}>
          From draw to dashboard,<br />
          <span style={{ color: COLORS.brand }}>in under two weeks.</span>
        </h2>
        <p style={{ fontSize: 18, color: COLORS.inkSoft, lineHeight: 1.6, marginTop: 20, maxWidth: 580 }}>
          We handle lab logistics, data normalisation, and EU compliance. You show up for the draw, then use the dashboard to make the next year measurable.
        </p>
      </div>
      <div style={{ borderTop: `1px solid ${COLORS.line}`, borderBottom: `1px solid ${COLORS.line}` }}>
        <div style={{ ...CONTENT_FRAME, display: "grid", gridTemplateColumns: "repeat(4, 1fr)" }}>
          {STEPS.map((s, i) => (
            <div key={s.n} style={{
              padding: "18px clamp(16px,2.5vw,32px)",
              borderLeft: i > 0 ? `1px solid ${COLORS.line}` : "none",
            }}>
              <div style={{ fontFamily: FONTS.mono, fontSize: 11, color: COLORS.brand, letterSpacing: 1.6 }}>{s.n}</div>
              <div style={{ fontSize: 14, fontWeight: 500, color: COLORS.inkSoft, marginTop: 4 }}>{s.title}</div>
              <div style={{ fontFamily: FONTS.mono, fontSize: 10, color: COLORS.inkMute, letterSpacing: 0.8, marginTop: 2 }}>{s.tag}</div>
            </div>
          ))}
        </div>
      </div>
      {STEPS.map((s, i) => (
        <div key={s.n} style={{
          display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))",
          borderTop: `1px solid ${COLORS.line}`,
        }}>
          <div style={{
            padding: "clamp(56px,7vw,96px) clamp(32px,5vw,80px)",
            display: "flex", flexDirection: "column", justifyContent: "center",
            background: i % 2 === 0 ? COLORS.canvas : COLORS.paper, minHeight: 500,
            order: i % 2 === 0 ? 0 : 1,
          }}>
            <div style={{ fontFamily: FONTS.display, fontSize: "clamp(72px,9vw,120px)", fontWeight: 300, lineHeight: 1, color: COLORS.brandSoft, marginBottom: -4 }}>{s.n}</div>
            <div style={{ fontFamily: FONTS.mono, fontSize: 11, color: COLORS.inkMute, letterSpacing: 1.4, textTransform: "uppercase", marginBottom: 14 }}>{s.tag}</div>
            <h3 style={{ fontFamily: FONTS.display, fontSize: "clamp(32px,4vw,52px)", fontWeight: 700, lineHeight: 1.08, margin: "0 0 20px", color: COLORS.ink }}>{s.title}</h3>
            <p style={{ fontSize: 17, lineHeight: 1.65, color: COLORS.inkSoft, margin: 0, maxWidth: 460 }}>{s.body}</p>
          </div>
          <div style={{
            minHeight: 500, background: `linear-gradient(135deg, ${["#2b1e16", "#33291f", "#3a2e25", "#2e2820"][i]} 0%, #1a120c 100%)`,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "rgba(255,255,255,0.36)", fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase",
          }}>[ photo placeholder · {s.title.toLowerCase()} ]</div>
        </div>
      ))}
    </section>
  );
}

// ─── Bento ───────────────────────────────────────────────────────────
const STANDARD = [
  { code: "01", name: "Cardiovascular",   markers: ["LDL-C", "HDL-C", "ApoB", "Lp(a)", "Triglycerides", "hs-CRP", "Homocysteine"] },
  { code: "02", name: "Metabolic",        markers: ["Glucose", "HbA1c", "Insulin", "HOMA-IR", "C-peptide"] },
  { code: "03", name: "Hormonal",         markers: ["Testosterone", "SHBG", "DHEA-S", "Cortisol", "Estradiol", "TSH", "fT3", "fT4"] },
  { code: "04", name: "Inflammation",     markers: ["hs-CRP", "ESR", "Ferritin", "Fibrinogen", "IL-6", "WBC diff"] },
  { code: "05", name: "Liver and Kidney", markers: ["ALT", "AST", "GGT", "Albumin", "Creatinine", "eGFR", "Cystatin C"] },
  { code: "06", name: "Nutrients",        markers: ["Vitamin D", "B12", "Folate", "Magnesium", "Zinc", "Selenium", "Omega-3 Index"] },
  { code: "07", name: "Hematology",       markers: ["CBC", "Hgb", "Hct", "MCV", "Platelets", "Reticulocytes"] },
  { code: "09", name: "Musculoskeletal",  markers: ["Calcium", "Phosphate", "ALP", "PTH", "Uric Acid", "Creatine Kinase", "Vitamin K2"] },
  { code: "10", name: "Digestive",        markers: ["Calprotectin", "Zonulin", "H. pylori Ab", "Secretory IgA", "Lipase", "Amylase"] },
];
const WGS = { code: "08", name: "Optional WGS", markers: ["Existing VCF", "GLI score", "ClinVar", "CPIC", "Aging hallmarks"] };

function Bento({ onCheckout }) {
  return (
    <section id="what-we-test" style={{ ...SECTION_PAD, background: COLORS.paper, borderTop: `1px solid ${COLORS.line}` }}>
      <div style={CONTENT_FRAME}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))", gap: 64, marginBottom: 64, alignItems: "end" }}>
          <h2 style={H2}>
            The annual panel for people<br />
            <span style={{ color: COLORS.brand }}>who already track everything else.</span>
          </h2>
          <p style={{ fontSize: 17, color: COLORS.inkSoft, lineHeight: 1.65, maxWidth: 520, margin: 0 }}>
            Sleep, HRV, and training data are useful. Bloodwork shows the biology underneath. We group the panel by system so you can see what changed, what matters, and what needs follow-up.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          {STANDARD.map((sys) => (
            <article key={sys.code} style={{
              background: COLORS.canvas, border: `1px solid ${COLORS.line}`,
              borderRadius: 12, padding: "22px 24px",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <span style={{ fontFamily: FONTS.mono, fontSize: 10, letterSpacing: 1.4, color: COLORS.inkMute }}>{sys.code}</span>
                <span style={{ fontFamily: FONTS.mono, fontSize: 10, color: COLORS.inkMute }}>{sys.markers.length} markers</span>
              </div>
              <h3 style={{ fontFamily: FONTS.display, fontSize: 22, fontWeight: 700, lineHeight: 1.05, margin: "0 0 12px", color: COLORS.ink }}>{sys.name}</h3>
              <div style={{ fontFamily: FONTS.mono, fontSize: 11, letterSpacing: 0.3, lineHeight: 1.9, color: COLORS.inkSoft }}>
                {sys.markers.slice(0, 4).map(m => <div key={m}>- {m}</div>)}
                {sys.markers.length > 4 && (
                  <div style={{ color: COLORS.inkMute }}>+{sys.markers.length - 4} more</div>
                )}
              </div>
            </article>
          ))}
          <article style={{
            gridColumn: "1 / -1", background: COLORS.ink, border: `1px solid ${COLORS.ink}`,
            borderRadius: 12, padding: "28px 32px",
            display: "grid", gridTemplateColumns: "1fr auto", gap: 24, alignItems: "center",
          }}>
            <div>
              <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 12 }}>
                <span style={{ fontFamily: FONTS.mono, fontSize: 10, letterSpacing: 1.4, color: "#a8a59c" }}>{WGS.code}</span>
                <span style={{ fontFamily: FONTS.mono, fontSize: 10, color: COLORS.brand, letterSpacing: 0.8, textTransform: "uppercase" }}>Optional add-on</span>
              </div>
              <h3 style={{ fontFamily: FONTS.display, fontSize: 28, fontWeight: 700, color: "#fff", margin: "0 0 10px" }}>{WGS.name}</h3>
              <div style={{ fontFamily: FONTS.mono, fontSize: 11, lineHeight: 1.9, color: "#a8a59c", display: "flex", gap: 24, flexWrap: "wrap" }}>
                {WGS.markers.map(m => <span key={m}>- {m}</span>)}
              </div>
            </div>
            <Btn variant="primary" onClick={onCheckout}>Add genomics</Btn>
          </article>
        </div>
      </div>
    </section>
  );
}

// ─── Pricing ─────────────────────────────────────────────────────────
const MEMBERSHIP = [
  { name: "Annual biomarker baseline", status: "included" },
  { name: "Private healthspan dashboard", status: "included" },
  { name: "Results walkthrough", status: "included" },
  { name: "Personalised protocol", status: "included" },
  { name: "Raw-data export", status: "included" },
  { name: "Annual retest path", status: "included" },
  { name: "Optional genomics", status: "later" },
  { name: "Specialist add-ons", status: "later" },
];

function Pricing({ onCheckout }) {
  return (
    <section id="membership" style={{
      background: COLORS.night, color: "#fff",
      padding: "clamp(80px,10vw,128px) clamp(20px,5vw,64px)",
      position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: -160, right: -160, width: 600, height: 600, borderRadius: 999, background: COLORS.brand, opacity: 0.10, filter: "blur(120px)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: -200, left: -160, width: 600, height: 600, borderRadius: 999, background: COLORS.brand, opacity: 0.07, filter: "blur(140px)", pointerEvents: "none" }} />
      <div style={{ ...CONTENT_FRAME, position: "relative", zIndex: 1,
        display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))",
        gap: 80, alignItems: "center" }}>
        <div>
          <h2 style={{ ...H2, color: "#fff", fontSize: "clamp(44px,6vw,80px)" }}>
            Build your first<br />European healthspan<br />
            <span style={{ color: COLORS.brand }}>baseline.</span>
          </h2>
          <p style={{ fontSize: 18, color: "rgba(255,255,255,0.66)", lineHeight: 1.65, marginTop: 28, maxWidth: 480 }}>
            Annual biomarkers, EU-hosted data controls, and a protocol built around your actual numbers.
          </p>
          <div style={{ marginTop: 40 }}>
            {MEMBERSHIP.map((item) => (
              <div key={item.name} style={{
                display: "grid", gridTemplateColumns: "22px 1fr auto",
                gap: 12, padding: "12px 0",
                borderBottom: "1px solid rgba(255,255,255,0.07)", alignItems: "center",
              }}>
                <Check />
                <div style={{ fontSize: 14, fontWeight: 500, color: "rgba(255,255,255,0.90)" }}>{item.name}</div>
                <div style={{ fontFamily: FONTS.mono, fontSize: 11, color: item.status === "included" ? COLORS.good : "rgba(255,255,255,0.32)", textAlign: "right" }}>
                  {item.status}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div style={{
          position: "relative", borderRadius: 20,
          border: "1px solid rgba(255,255,255,0.18)",
          background: "linear-gradient(135deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.06) 100%)",
          backdropFilter: "blur(32px) saturate(160%) contrast(1.04)",
          WebkitBackdropFilter: "blur(32px) saturate(160%) contrast(1.04)",
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.32), inset 0 -1px 0 rgba(255,255,255,0.08), 0 32px 80px rgba(0,0,0,0.36)",
          padding: 40, overflow: "hidden",
        }}>
          <div style={{ position: "absolute", inset: 1, borderRadius: 19, border: "1px solid rgba(255,255,255,0.10)", pointerEvents: "none" }} />
          <div style={{ fontFamily: FONTS.mono, fontSize: 11, color: COLORS.brand, letterSpacing: 1.6, textTransform: "uppercase", marginBottom: 16 }}>
            Core membership
          </div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 8 }}>
            <span style={{ fontFamily: FONTS.display, fontSize: "clamp(64px,8vw,96px)", fontWeight: 700, lineHeight: 0.95, color: "#fff" }}>EUR 199</span>
            <span style={{ fontFamily: FONTS.mono, fontSize: 14, color: "rgba(255,255,255,0.50)" }}>/year</span>
          </div>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.56)", marginBottom: 32, lineHeight: 1.5 }}>
            Auto-renews at the same price. Cancel any time.
          </p>
          <div style={{ display: "grid", gap: 10, marginBottom: 32 }}>
            {["100+ biomarker target panel", "Private EU-hosted dashboard", "Personalised ranked protocol", "Raw-data export", "Results walkthrough"].map((f) => (
              <div key={f} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 14, color: "rgba(255,255,255,0.82)" }}>
                <span style={{ color: COLORS.brand, fontWeight: 700, flexShrink: 0 }}>+</span>{f}
              </div>
            ))}
          </div>
          <Btn variant="primary" full onClick={onCheckout}>Become a Member</Btn>
          <div style={{ marginTop: 16, fontFamily: FONTS.mono, fontSize: 10, color: "rgba(255,255,255,0.36)", letterSpacing: 1, textAlign: "center", textTransform: "uppercase" }}>
            14-day money-back · One-click cancel
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── FAQ ─────────────────────────────────────────────────────────────
const FAQS = [
  { q: "Is this a medical service?", a: "No. foreverbetter is a wellness and lifestyle insights service. It helps you understand patterns in biomarker and optional genomic data, but it does not diagnose, prescribe, or replace a physician." },
  { q: "Who is this for?", a: "Health-literate Europeans who already train, track sleep, or collect lab results, and want a yearly baseline with clear priorities instead of scattered PDFs and generic advice." },
  { q: "Where is my data stored?", a: "The product is built around EU data residency, explicit consent for special-category health and genetic data, and member-controlled export and deletion." },
  { q: "Do I need whole-genome sequencing?", a: "No. The core product is biomarker-first. Genomic interpretation is an optional add-on, not a requirement." },
  { q: "Can I cancel?", a: "Yes. The membership is annual and can be cancelled before renewal. No long-term commitment is required beyond the current paid year." },
];

function Faq() {
  return (
    <section id="faq" style={{ ...SECTION_PAD, background: COLORS.canvas }}>
      <div style={{ ...CONTENT_FRAME, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))", gap: 96, alignItems: "start" }}>
        <div style={{ position: "sticky", top: 88 }}>
          <h2 style={{ ...H2, fontSize: "clamp(36px,4.5vw,56px)" }}>
            Questions we get,<br />
            <span style={{ color: COLORS.brand }}>honestly answered.</span>
          </h2>
          <p style={{ fontSize: 16, color: COLORS.inkSoft, lineHeight: 1.65, marginTop: 20 }}>
            Still curious? Email{" "}
            <a style={{ color: COLORS.brand, fontFamily: FONTS.mono, fontSize: 13 }}>hello@foreverbetter.com</a>
            {" "}— a founder reads every message.
          </p>
        </div>
        <div>
          {FAQS.map((faq, i) => (
            <details key={faq.q} open={i === 0} style={{
              borderTop: i === 0 ? `1.5px solid ${COLORS.ink}` : "none",
              borderBottom: `1px solid ${COLORS.line}`, padding: "22px 0",
            }}>
              <summary style={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", listStyle: "none", gap: 24 }}>
                <span style={{ fontFamily: FONTS.display, fontSize: 22, fontWeight: 700, lineHeight: 1.2, color: COLORS.ink }}>{faq.q}</span>
                <span style={{ fontFamily: FONTS.mono, fontSize: 18, color: COLORS.brand, flexShrink: 0 }}>+</span>
              </summary>
              <p style={{ fontSize: 15, lineHeight: 1.65, color: COLORS.inkSoft, margin: "14px 0 0", maxWidth: 640 }}>{faq.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Footer ──────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ background: COLORS.paper, color: COLORS.ink }}>
      <div style={{ background: COLORS.canvas, borderTop: `1px solid ${COLORS.line}`, borderBottom: `1px solid ${COLORS.line}`, padding: "32px clamp(20px,5vw,64px)" }}>
        <div style={{ ...CONTENT_FRAME, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 220px), 1fr))", gap: 32, alignItems: "start" }}>
          <Eyebrow><span style={{ color: COLORS.brand }}>Medical disclaimer</span></Eyebrow>
          <p style={{ fontSize: 13, color: COLORS.inkSoft, lineHeight: 1.7, maxWidth: 860, margin: 0 }}>
            foreverbetter is a wellness and lifestyle service, not a medical service. The biomarker analysis, healthspan score, genomic interpretation, and protocol recommendations are informational only. They do not constitute medical advice, diagnosis, treatment, or prescription. Always consult a qualified physician before changing medication, diet, supplementation, or training.
          </p>
        </div>
      </div>
      <div style={{ padding: "56px clamp(20px,5vw,64px) 28px" }}>
        <div style={{ ...CONTENT_FRAME, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 180px), 1fr))", gap: 40, marginBottom: 48 }}>
          <div>
            <Logo />
            <p style={{ fontSize: 13, color: COLORS.inkSoft, marginTop: 14, lineHeight: 1.65, maxWidth: 260 }}>
              Annual biomarker readouts, evidence-backed protocols, and optional genomic context. Portugal launch, Europe expansion.
            </p>
          </div>
          {[
            ["Product", ["How it works", "What we test", "Membership", "Pricing"]],
            ["Company", ["About", "Blog", "Press", "Careers", "Contact"]],
            ["Trust", ["Privacy", "GDPR consent", "Sub-processors", "Disclaimers"]],
            ["Available in", ["Portugal — live", "Spain — next", "Germany — planned", "Netherlands — planned"]],
          ].map(([heading, items]) => (
            <div key={heading}>
              <Eyebrow>{heading}</Eyebrow>
              <div style={{ marginTop: 14 }}>
                {items.map((item) => (
                  <div key={item} style={{ fontSize: 13, color: COLORS.ink, padding: "5px 0" }}>{item}</div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </footer>
  );
}

// ─── Checkout modal ──────────────────────────────────────────────────
function CheckoutSheet({ open, onClose }) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(10,8,6,0.72)",
      backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)",
      zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24,
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: COLORS.paper, border: `1px solid ${COLORS.line}`, borderRadius: 14,
        maxWidth: 480, width: "100%", padding: 36, position: "relative",
      }}>
        <button onClick={onClose} style={{
          position: "absolute", top: 14, right: 14,
          background: "transparent", border: 0, fontSize: 22, color: COLORS.inkMute, cursor: "pointer", lineHeight: 1,
        }}>×</button>
        <Eyebrow>Checkout · Step 1 of 2</Eyebrow>
        <h2 style={{ ...H2, fontSize: 32, margin: "12px 0 6px" }}>Founding membership</h2>
        <p style={{ fontSize: 14, color: COLORS.inkSoft, margin: "0 0 24px" }}>
          You're joining the Portugal founding cohort.
        </p>
        <div style={{ display: "grid", gap: 12, marginBottom: 24 }}>
          {[
            ["Annual biomarker baseline", "EUR 199"],
            ["Optional genomics", "+ EUR 49"],
            ["Lab fees (paid to lab)", "EUR 280–520"],
          ].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${COLORS.line}` }}>
              <span style={{ fontSize: 14, color: COLORS.ink }}>{k}</span>
              <span style={{ fontFamily: FONTS.mono, fontSize: 13, color: COLORS.inkSoft }}>{v}</span>
            </div>
          ))}
        </div>
        <Btn variant="primary" full>Continue to payment</Btn>
        <div style={{ marginTop: 12, fontFamily: FONTS.mono, fontSize: 10, color: COLORS.inkMute, letterSpacing: 1, textAlign: "center", textTransform: "uppercase" }}>
          Stripe · EU hosted · 14-day money-back
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Nav, Hero, TrustStrip, Steps, Bento, Pricing, Faq, Footer, CheckoutSheet });
