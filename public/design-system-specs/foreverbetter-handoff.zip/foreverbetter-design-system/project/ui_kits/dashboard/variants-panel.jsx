/* global React, DCOLORS, DFONTS, Section */

const PRS = [
  { lbl: "Coronary artery disease", pct: 11,  level: "LOWER THAN AVERAGE", icon: "✓" },
  { lbl: "Type 2 diabetes",         pct: 10,  level: "LOWER THAN AVERAGE", icon: "✓" },
  { lbl: "Breast cancer",           pct: 12,  level: "LOWER THAN AVERAGE", icon: "✓" },
  { lbl: "Alzheimer's disease",     pct: 13,  level: "LOWER THAN AVERAGE", icon: "✓" },
  { lbl: "VO₂max",                  pct: 27,  level: "AVERAGE",            icon: "—" },
  { lbl: "Grip strength",           pct: 9,   level: "LOWER",              icon: "↓" },
  { lbl: "Bone mineral density",    pct: 8,   level: "LOWER",              icon: "↓" },
  { lbl: "HDL cholesterol",         pct: 13,  level: "LOWER",              icon: "↓" },
  { lbl: "LDL cholesterol",         pct: 58,  level: "AVERAGE",            icon: "—" },
  { lbl: "Triglycerides",           pct: 23,  level: "AVERAGE",            icon: "—" },
];

function Variants() {
  return (
    <div data-screen-label="Dashboard — Genetic Variants">
      <Section title="Polygenic Risk Scores" subtitle="Aggregate genetic risk across multiple variants for common complex diseases">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 14 }}>
          {PRS.map((p) => (
            <article key={p.lbl} style={{
              background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
              borderRadius: 10, padding: 18,
              display: "flex", flexDirection: "column", justifyContent: "space-between", minHeight: 200,
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <span style={{
                  fontFamily: DFONTS.body, fontSize: 10, fontWeight: 700, letterSpacing: "0.06em",
                  padding: "3px 9px", borderRadius: 999,
                  background: p.level.includes("LOWER") ? "oklch(48% 0.12 248 / 0.10)" : DCOLORS.bgSecondary,
                  color: p.level.includes("LOWER") ? DCOLORS.neutral : DCOLORS.inkSoft,
                }}>{p.level}</span>
                <span style={{
                  width: 22, height: 22, borderRadius: 5,
                  background: p.icon === "✓" ? DCOLORS.optimal : p.icon === "↓" ? DCOLORS.inkSoft : "transparent",
                  border: p.icon === "—" ? `1.5px solid ${DCOLORS.border}` : "0",
                  color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 13,
                }}>{p.icon === "—" ? "" : p.icon}</span>
              </div>
              <p style={{ fontSize: 13, color: DCOLORS.inkSoft, lineHeight: 1.5, margin: "0 0 12px" }}>
                Your polygenic profile for {p.lbl.toLowerCase()} is {p.level.toLowerCase()}.
              </p>
              <div style={{ fontFamily: DFONTS.mono, fontSize: 12, color: DCOLORS.ink, fontWeight: 600 }}>
                Percentile: <span style={{ color: DCOLORS.accent, fontVariantNumeric: "tabular-nums" }}>{p.pct}%</span>
              </div>
            </article>
          ))}
        </div>
      </Section>
    </div>
  );
}

window.Variants = Variants;
