/* global React, DCOLORS, DFONTS, Section, FindingsCell, TierBadge, RiskBadge, Sparkbar */

// ─── Hero ─────────────────────────────────────────────────────────────
function HeroCard() {
  return (
    <article style={{
      background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
      borderRadius: 14, padding: 32, marginBottom: 48,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
      position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: -80, right: -80, width: 260, height: 260, background: "radial-gradient(circle at center, oklch(58% 0.22 22 / 0.05) 0%, transparent 70%)", borderRadius: "50%", pointerEvents: "none" }} />
      <button style={{
        position: "absolute", top: 20, right: 20, zIndex: 5,
        display: "flex", alignItems: "center", gap: 6,
        padding: "10px 16px", borderRadius: 999, minHeight: 40,
        background: DCOLORS.accent, border: 0,
        fontFamily: DFONTS.body, fontSize: 13, fontWeight: 600, color: "#fff", cursor: "pointer",
      }}>✕ Share</button>

      <div style={{ display: "flex", gap: 32, alignItems: "center", position: "relative", zIndex: 1, flexWrap: "wrap" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, minWidth: 200 }}>
          {/* Whoop-style ring: thin track + single-color progress arc keyed to status */}
          <div style={{ position: "relative", width: 140, height: 140 }}>
            <svg width="140" height="140" viewBox="0 0 120 120" style={{ transform: "rotate(-90deg)", display: "block" }} aria-hidden="true">
              <circle cx="60" cy="60" r="56" fill="none" stroke={DCOLORS.border} strokeWidth="10" />
              <circle cx="60" cy="60" r="56" fill="none" stroke={DCOLORS.moderate} strokeWidth="10" strokeLinecap="round"
                strokeDasharray="351.86" strokeDashoffset={351.86 * (1 - 0.46)} />
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
              <div style={{ fontFamily: DFONTS.display, fontSize: 44, fontWeight: 700, letterSpacing: "-0.04em", lineHeight: 1, fontVariantNumeric: "tabular-nums", color: DCOLORS.ink }}>46</div>
              <div style={{ fontFamily: DFONTS.mono, fontSize: 9.5, fontWeight: 600, letterSpacing: "0.22em", textTransform: "uppercase", color: DCOLORS.inkMute, marginTop: 4 }}>GLI</div>
            </div>
          </div>
          <div style={{ fontFamily: DFONTS.mono, fontSize: 10, fontWeight: 600, letterSpacing: "0.22em", textTransform: "uppercase", color: DCOLORS.inkMute }}>HEALTHSPAN SCORE</div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", justifyContent: "center" }}>
            <div style={{ fontFamily: DFONTS.display, fontSize: 22, fontWeight: 700, letterSpacing: "-0.03em", color: DCOLORS.ink, lineHeight: 1 }}>Top 46%</div>
            <span style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              padding: "3px 10px", borderRadius: 999,
              fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase",
              background: "oklch(55% 0.14 72 / 0.12)", color: "oklch(55% 0.14 72)",
            }}><span style={{ width: 5, height: 5, borderRadius: 999, background: "currentColor" }} />Moderate</span>
          </div>
          <p style={{ fontFamily: DFONTS.body, fontSize: 12, color: DCOLORS.inkSoft, lineHeight: 1.55, maxWidth: 280, margin: 0, textAlign: "center" }}>
            Your genomic profile shows several areas where targeted interventions can make a meaningful difference.
          </p>
          <div style={{ fontSize: 11, color: DCOLORS.inkMute, textAlign: "center" }}>
            Focus areas: immune response, eye health, dna repair
          </div>
        </div>

        <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 16 }}>
          <div style={{ gridColumn: "1 / -1", fontFamily: DFONTS.body, fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: DCOLORS.inkMute }}>INNATE STRENGTHS</div>
          {[
            { rs: "rs5744168", score: 85 },
            { rs: "rs2070744", score: 85 },
          ].map((s) => (
            <article key={s.rs} style={{
              background: "oklch(58% 0.22 22 / 0.03)", border: "1px solid oklch(58% 0.22 22 / 0.1)",
              borderRadius: 8, padding: 16, minHeight: 120,
            }}>
              <span style={{ display: "inline-flex", padding: "2px 8px", borderRadius: 999, marginBottom: 8,
                fontSize: 10, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase",
                background: "oklch(58% 0.22 22 / 0.10)", color: DCOLORS.accent }}>Innate strength</span>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                <div style={{ fontFamily: DFONTS.body, fontSize: 14, fontWeight: 700, color: DCOLORS.ink, letterSpacing: "-0.01em" }}>Protective {s.rs}</div>
                <div style={{ fontFamily: DFONTS.mono, fontSize: 20, fontWeight: 700, fontVariantNumeric: "tabular-nums", color: DCOLORS.accent }}>{s.score}</div>
              </div>
              <div style={{ fontSize: 13, lineHeight: 1.5, color: DCOLORS.inkSoft, marginBottom: 10 }}>
                You have a genetic advantage in protective {s.rs}. This means your natural biology supports healthy function in this area.
              </div>
              <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                <span style={{ padding: "2px 8px", borderRadius: 999, fontSize: 10, fontWeight: 600, background: "oklch(55% 0.16 145 / 0.1)", color: DCOLORS.optimal }}>High Impact</span>
                <span style={{ padding: "2px 8px", borderRadius: 999, fontSize: 10, fontWeight: 600, background: "oklch(48% 0.12 248 / 0.1)", color: DCOLORS.neutral }}>Moderate confidence</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </article>
  );
}

// ─── Category Breakdown ───────────────────────────────────────────────
const CATEGORIES = [
  { icon: "🌿", title: "Genetic Vulnerability", score: 39, color: DCOLORS.accent,  meta: "74 markers · 45 flagged" },
  { icon: "💊", title: "Pharmacological",     score: 25, color: DCOLORS.neutral, meta: "74 markers · 28 interactions" },
  { icon: "🌙", title: "Hereditary",          score: 30, color: DCOLORS.optimal, meta: "25 markers · At Risk" },
  { icon: "★",  title: "Personal Traits",     score: 45, color: DCOLORS.accent,  meta: "38 markers · 7 insights" },
  { icon: "🩺", title: "Wellness",            score: 48, color: DCOLORS.optimal, meta: "80 markers · 14 recs" },
  { icon: "🧬", title: "Ancestry",            score: 75, color: "#8b5cf6",       meta: "14 markers · 2 haplogroups" },
];

function CategoryGrid() {
  return (
    <Section title="Category Breakdown" subtitle="6 dimensions of your genetic profile">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 14 }}>
        {CATEGORIES.map((c) => (
          <article key={c.title} style={{
            background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
            borderRadius: 8, padding: 18, cursor: "pointer",
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: 5, marginBottom: 12,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, background: DCOLORS.bgSecondary,
            }}>{c.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: DCOLORS.ink, marginBottom: 6 }}>{c.title}</div>
            <Sparkbar value={c.score} color={c.color} />
            <div style={{ fontFamily: DFONTS.mono, fontSize: 18, fontWeight: 700, fontVariantNumeric: "tabular-nums", color: c.color }}>
              {c.title === "Ancestry" ? `${c.score}%` : c.score}
            </div>
            <div style={{ fontSize: 11, color: DCOLORS.inkMute, marginTop: 2 }}>{c.meta}</div>
          </article>
        ))}
      </div>
    </Section>
  );
}

// ─── Insights ─────────────────────────────────────────────────────────
const INSIGHTS = [
  { title: "Methylation", body: "Your methylation is moderate. There is room for optimization.", count: 3 },
  { title: "Immune Response", body: "Your immune response is below optimal. Consider the actions below to improve.", count: 2 },
  { title: "Thyroid Function", body: "Your thyroid function is below optimal. Consider the actions below to improve.", count: 2 },
  { title: "Eye Health", body: "Your eye health is below optimal. Consider the actions below to improve.", count: 2 },
];

function Insights() {
  return (
    <Section title="Key Insights" subtitle="What your data is telling you">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 14 }}>
        {INSIGHTS.map((i) => (
          <article key={i.title} style={{
            background: DCOLORS.surface, borderLeft: `3px solid ${DCOLORS.borderStrong}`,
            borderRadius: "0 8px 8px 0", padding: 20,
            boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
          }}>
            <div style={{ fontFamily: DFONTS.display, fontSize: 15, fontWeight: 700, color: DCOLORS.ink, letterSpacing: "-0.01em", marginBottom: 6 }}>{i.title}</div>
            <div style={{ fontSize: 13, lineHeight: 1.6, color: DCOLORS.inkSoft, marginBottom: 12 }}>{i.body}</div>
            <span style={{ fontSize: 12, fontWeight: 600, color: DCOLORS.accent }}>{i.count} recommended actions →</span>
          </article>
        ))}
      </div>
    </Section>
  );
}

// ─── Action Plan ──────────────────────────────────────────────────────
const ACTIONS = [
  { id: "CHOLESTEROL", title: "Cholesterol", meta: "PCSK9-mediated LDL receptor recycling", body: "PCSK9-mediated LDL receptor recycling", steps: ["Consider PCSK9 inhibitor", "Aggressive statin therapy", "Monitor and re-assess in 3–6 months"] },
  { id: "LIPID_METABOLISM", title: "Lipid Metabolism", meta: "APOB and PCSK9 regulation of LDL cholesterol", body: "APOB and PCSK9 regulation of LDL cholesterol", steps: ["Follow heart-healthy diet", "Consider statin therapy", "Monitor and re-assess in 3–6 months"] },
  { id: "CARDIOMYOPATHY_RISK", title: "Cardiomyopathy Risk", meta: "Genetic variants in sarcomere genes (MYH7, MYBPC3)", body: "Genetic variants in sarcomere genes (MYH7, MYBPC3, TNNT2, TNNI3), desmosomal genes (PKP2, DSP, DSG2), and other structural proteins that increase susceptibility.", steps: ["Refer to cardiology for echocardiogram", "Serial cardiac monitoring", "Monitor and re-assess in 3–6 months"] },
  { id: "CANCER_SUSCEPTIBILITY", title: "Cancer Susceptibility", meta: "Inherited predisposition to malignancies from germ", body: "Inherited predisposition to malignancies from germline pathogenic variants in tumor suppressor genes, oncogenes, and DNA repair genes (e.g., BRCA1/2, TP53, MLH1, APC, CDKN2A).", steps: ["Genetic counseling and risk assessment", "Enhanced cancer screening protocol", "Monitor and re-assess in 3–6 months"] },
];

function ActionPlan() {
  return (
    <Section title="Your Action Plan" subtitle="Your DNA → what to do about it">
      <article style={{
        background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
        borderRadius: 14, padding: 28, marginBottom: 20,
        boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
      }}>
        <h3 style={{ fontFamily: DFONTS.display, fontSize: 18, fontWeight: 700, margin: "0 0 18px", color: DCOLORS.ink, letterSpacing: "-0.015em" }}>How foreverbetter turns your DNA into a plan</h3>
        {[
          ["Built on your full genetic picture", "Your plan uses your full genetic data across all 6 categories: vulnerability, pharmacogenetics, hereditary risk, traits, wellness, and ancestry. The system looks for patterns across markers."],
          ["Every step is matched to your genotype", "Each recommendation is actionable, time-bound, and tied to the specific gene variant that triggered it. Every suggestion traces back to a specific gene variant, with evidence citations attached."],
          ["Prioritized by what matters most", "High priority = drug sensitivities and actionable risks (share with your doctor). Medium priority = daily optimizations you control (diet, sleep, supplementation). Everything is graded by impact and difficulty so you know where to start."],
        ].map(([t, b], i) => (
          <div key={t} style={{ display: "grid", gridTemplateColumns: "30px 1fr", gap: 14, marginBottom: 14, alignItems: "flex-start" }}>
            <span style={{
              width: 24, height: 24, borderRadius: "50%", background: DCOLORS.accent, color: "#fff",
              display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700,
              fontFamily: DFONTS.body,
            }}>{i + 1}</span>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: DCOLORS.ink, marginBottom: 2 }}>{t}</div>
              <div style={{ fontSize: 12, color: DCOLORS.inkSoft, lineHeight: 1.55 }}>{b}</div>
            </div>
          </div>
        ))}
      </article>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 16 }}>
        {ACTIONS.map((a) => (
          <article key={a.id} style={{
            background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
            borderRadius: 8, padding: 22,
            boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
          }}>
            <RiskBadge level="high" />
            <h4 style={{ fontFamily: DFONTS.display, fontSize: 17, fontWeight: 700, margin: "10px 0 6px", color: DCOLORS.ink, letterSpacing: "-0.015em" }}>{a.title}</h4>
            <div style={{ fontFamily: DFONTS.mono, fontSize: 11, color: DCOLORS.inkMute, letterSpacing: "0.03em", marginBottom: 10 }}>{a.id} · {a.meta}</div>
            <div style={{ fontSize: 13, color: DCOLORS.inkSoft, lineHeight: 1.55, marginBottom: 14 }}>{a.body}</div>
            <ol style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 8 }}>
              {a.steps.map((s, i) => (
                <li key={s} style={{ display: "flex", gap: 10, alignItems: "flex-start", fontSize: 13, color: DCOLORS.ink }}>
                  <span style={{
                    width: 20, height: 20, borderRadius: "50%", background: DCOLORS.accent, color: "#fff",
                    flexShrink: 0, display: "inline-flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 700, marginTop: 1,
                  }}>{i + 1}</span>
                  <span>{s}</span>
                </li>
              ))}
            </ol>
          </article>
        ))}
      </div>
    </Section>
  );
}

// ─── Protocols ────────────────────────────────────────────────────────
const PROTOCOLS = [
  { tier: 1, title: "Core Optimization Protocol", impact: "HIGH", difficulty: "MODERATE", checklist: [["Take methylfolate", true], ["Consider PCSK9 inhibitor", false], ["Cascade family screening", false]] },
  { tier: 1, title: "Maintenance Protocol",       impact: "MEDIUM-HIGH", difficulty: "MODERATE", checklist: [["Take methylfolate", true], ["Consider PCSK9 inhibitor", false], ["Cascade family screening", false]] },
  { tier: 2, title: "Emerging Add-on (placeholder)", impact: "MEDIUM", difficulty: "LOW", checklist: [["Add cofactor stack", false], ["Re-test at 12 weeks", false]] },
];

function Protocols() {
  return (
    <Section title="Recommended Protocols" subtitle="Action plans matched to your genotype">
      <p style={{ fontSize: 13, color: DCOLORS.inkSoft, lineHeight: 1.6, marginBottom: 18 }}>
        Protocols are structured multi-week programs built from your genetic results. Each combines your biology with evidence-graded actions split into phases, with milestones and check-ins along the way.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 16 }}>
        {PROTOCOLS.map((p) => (
          <article key={p.title} style={{
            background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
            borderRadius: 10, padding: 22, display: "flex", flexDirection: "column", gap: 12,
            boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
          }}>
            <TierBadge tier={p.tier} />
            <h4 style={{ fontFamily: DFONTS.display, fontSize: 18, fontWeight: 700, margin: 0, color: DCOLORS.ink, letterSpacing: "-0.015em" }}>{p.title}</h4>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <span style={{ fontFamily: DFONTS.mono, fontSize: 10, padding: "3px 10px", borderRadius: 999, background: DCOLORS.bgElevated, color: DCOLORS.inkSoft, letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 600 }}>Impact: {p.impact}</span>
              <span style={{ fontFamily: DFONTS.mono, fontSize: 10, padding: "3px 10px", borderRadius: 999, background: DCOLORS.bgElevated, color: DCOLORS.inkSoft, letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 600 }}>Difficulty: {p.difficulty}</span>
            </div>
            <div style={{ height: 1, background: DCOLORS.border }} />
            <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 8 }}>
              {p.checklist.map(([s, done]) => (
                <li key={s} style={{ display: "flex", gap: 10, fontSize: 13, color: DCOLORS.ink, alignItems: "center" }}>
                  <span style={{
                    width: 18, height: 18, borderRadius: "50%",
                    border: done ? "0" : `1.5px solid ${DCOLORS.borderStrong}`,
                    background: done ? DCOLORS.optimal : "transparent",
                    color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, flexShrink: 0,
                  }}>{done ? "✓" : ""}</span>
                  <span style={{ color: done ? DCOLORS.inkMute : DCOLORS.ink, textDecoration: done ? "none" : "none" }}>{s}</span>
                </li>
              ))}
            </ul>
            <button style={{
              marginTop: "auto", padding: "12px 20px", borderRadius: 6,
              background: DCOLORS.accent, color: "#fff", border: 0, cursor: "pointer",
              fontFamily: DFONTS.body, fontSize: 14, fontWeight: 600, letterSpacing: "0.01em",
            }}>View Protocol</button>
          </article>
        ))}
      </div>
    </Section>
  );
}

function Overview() {
  return (
    <div data-screen-label="Dashboard — Overview">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, marginBottom: 32 }}>
        <FindingsCell value="274" label="Curated Health Markers Analyzed" />
        <FindingsCell value="0"   label="Rare Functional Variants (VEP HIGH/MODERATE)" />
        <FindingsCell value="69"  label="ClinVar Pathogenic Findings" />
        <FindingsCell value="0"   label="CPIC Drug–Gene Interactions" />
      </div>
      <HeroCard />
      <CategoryGrid />
      <Insights />
      <ActionPlan />
      <Protocols />
    </div>
  );
}

Object.assign(window, { Overview });
