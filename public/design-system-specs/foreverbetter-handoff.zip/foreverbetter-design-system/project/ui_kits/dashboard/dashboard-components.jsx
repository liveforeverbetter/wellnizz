/* global React */
const { useState } = React;

const DCOLORS = {
  bgPrimary:   "#fafaf9",
  bgSecondary: "#f3f1ef",
  bgElevated:  "#eae6e2",
  surface:     "#ffffff",
  ink:         "#1a1514",
  inkSoft:     "#4a3f3a",
  inkMute:     "#7a6e68",
  inkFaint:    "#a0948e",
  inverse:     "#ffffff",
  border:      "#e7e2dd",
  borderStrong:"#c5beb7",
  accent:      "#df1e39",
  accentSoft:  "rgba(223,30,57,0.10)",
  optimal:     "oklch(52% 0.16 145)",
  neutral:     "oklch(48% 0.12 248)",
  moderate:    "oklch(55% 0.14 72)",
  critical:    "oklch(48% 0.20 22)",
  inactive:    "#a0948e",
};
const DFONTS = {
  display: '"Plus Jakarta Sans", system-ui, sans-serif',
  body:    '"Plus Jakarta Sans", system-ui, sans-serif',
  mono:    '"JetBrains Mono", ui-monospace, monospace',
};

function NavBar({ tab, onTab }) {
  const tabs = ["Overview", "Categories", "Protocols", "Genetic Variants"];
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 100, height: 64,
      background: "rgba(250,250,249,0.82)",
      backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
      borderBottom: `1px solid ${DCOLORS.border}`,
      display: "flex", alignItems: "center", justifyContent: "center",
    }}>
      <div style={{
        width: "100%", maxWidth: 1200, margin: "0 24px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <span style={{ fontFamily: '"DM Sans", system-ui, sans-serif', fontSize: 20, fontWeight: 700, color: DCOLORS.ink, letterSpacing: "-0.025em" }}>
          forever<span style={{ color: DCOLORS.accent }}>better</span>
        </span>
        <div style={{ display: "flex", gap: 4, background: DCOLORS.bgSecondary, borderRadius: 999, padding: 3 }}>
          {tabs.map((t) => (
            <button key={t} onClick={() => onTab(t)} style={{
              padding: "10px 18px", fontFamily: DFONTS.body, fontSize: 13, fontWeight: 600,
              borderRadius: 999, border: 0, cursor: "pointer",
              color: tab === t ? DCOLORS.ink : DCOLORS.inkSoft,
              background: tab === t ? DCOLORS.surface : "transparent",
              boxShadow: tab === t ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
              minHeight: 38,
            }}>{t}</button>
          ))}
        </div>
        <div style={{
          width: 32, height: 32, borderRadius: 999, background: DCOLORS.accent,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: DFONTS.body, fontSize: 12, fontWeight: 700, color: "#fff",
        }}>TE</div>
      </div>
    </nav>
  );
}

function Section({ title, subtitle, children }) {
  return (
    <section style={{ marginBottom: 56 }}>
      <header style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 20 }}>
        <h2 style={{ fontFamily: DFONTS.display, fontSize: 22, fontWeight: 700, letterSpacing: "-0.025em", margin: 0, color: DCOLORS.ink }}>{title}</h2>
        {subtitle ? <div style={{ fontFamily: DFONTS.body, fontSize: 13, color: DCOLORS.inkMute, fontWeight: 500 }}>{subtitle}</div> : null}
      </header>
      {children}
    </section>
  );
}

function FindingsCell({ value, label }) {
  return (
    <div style={{
      background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
      borderRadius: 8, padding: 16, textAlign: "center",
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
    }}>
      <div style={{ fontFamily: DFONTS.mono, fontSize: 24, fontWeight: 700, fontVariantNumeric: "tabular-nums", color: DCOLORS.ink, lineHeight: 1, marginBottom: 6 }}>{value}</div>
      <div style={{ fontFamily: DFONTS.body, fontSize: 11, color: DCOLORS.inkMute, fontWeight: 500, lineHeight: 1.4 }}>{label}</div>
    </div>
  );
}

function TierBadge({ tier }) {
  const map = {
    1: { lbl: "TIER 1 · ESTABLISHED", bg: "oklch(52% 0.16 145 / 0.12)", fg: "oklch(52% 0.16 145)" },
    2: { lbl: "TIER 2 · EMERGING",    bg: "oklch(48% 0.12 248 / 0.12)", fg: "oklch(48% 0.12 248)" },
    3: { lbl: "TIER 3 · INVESTIGATIONAL", bg: "rgba(122,110,104,0.15)", fg: DCOLORS.inkMute },
  };
  const s = map[tier] || map[1];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center",
      padding: "3px 10px", borderRadius: 999,
      fontFamily: DFONTS.body, fontSize: 10, fontWeight: 600, letterSpacing: "0.06em",
      background: s.bg, color: s.fg,
    }}>{s.lbl}</span>
  );
}

function RiskBadge({ level }) {
  const map = {
    high: { lbl: "HIGH PRIORITY", bg: "rgba(223,30,57,0.10)", fg: DCOLORS.accent },
    med:  { lbl: "MEDIUM",        bg: DCOLORS.bgElevated, fg: DCOLORS.moderate },
    low:  { lbl: "LOW",           bg: "oklch(52% 0.16 145 / 0.12)", fg: DCOLORS.optimal },
  };
  const s = map[level] || map.med;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", padding: "3px 10px",
      borderRadius: 999, fontFamily: DFONTS.body, fontSize: 10, fontWeight: 700,
      letterSpacing: "0.05em", textTransform: "uppercase",
      background: s.bg, color: s.fg,
    }}>{s.lbl}</span>
  );
}

function Sparkbar({ value, max = 100, color }) {
  return (
    <div style={{ height: 4, background: DCOLORS.bgElevated, borderRadius: 2, overflow: "hidden", marginBottom: 8 }}>
      <div style={{ height: "100%", width: `${(value / max) * 100}%`, background: color, borderRadius: 2 }} />
    </div>
  );
}

Object.assign(window, { DCOLORS, DFONTS, NavBar, Section, FindingsCell, TierBadge, RiskBadge, Sparkbar, useState });
