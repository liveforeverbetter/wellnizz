/* global React, DCOLORS, DFONTS, Section, TierBadge */

const PROTOCOL_LIB = [
  { tier: 1, title: "Methylation Optimization",   impact: "HIGH",        duration: "12 weeks", body: "Targets MTHFR C677T variants with L-methylfolate, B12, B6, and homocysteine retest at week 12.", phases: ["Baseline labs", "L-methylfolate 400mcg daily", "Cofactor stack", "Maintenance"] },
  { tier: 1, title: "ApoB Lowering",              impact: "HIGH",        duration: "6 months", body: "Nutrition-first approach to lower apolipoprotein B before pharmacological options. Re-tests every 12 weeks.", phases: ["Diet shift (saturated fat)", "Soluble fiber + omega-3", "Re-test at 12 weeks", "Physician escalation if needed"] },
  { tier: 2, title: "Inflammatory Load Reduction", impact: "MEDIUM-HIGH", duration: "ongoing", body: "hs-CRP reduction stack — emerging evidence. Sleep, exercise, omega-3, polyphenol-rich diet.", phases: ["Sleep hygiene baseline", "Polyphenol-rich diet", "Resistance training", "Re-test hs-CRP"] },
];

function Protocols() {
  return (
    <div data-screen-label="Dashboard — Protocols">
      <Section title="Protocol Library" subtitle="Evidence-graded, multi-phase programs">
        <div style={{ display: "grid", gap: 16 }}>
          {PROTOCOL_LIB.map((p) => (
            <article key={p.title} style={{
              background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
              borderRadius: 10, padding: 24,
              boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
            }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 12 }}>
                <TierBadge tier={p.tier} />
                <span style={{ fontFamily: DFONTS.mono, fontSize: 10, padding: "3px 10px", borderRadius: 999, background: DCOLORS.bgElevated, color: DCOLORS.inkSoft, letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 600 }}>Impact · {p.impact}</span>
                <span style={{ fontFamily: DFONTS.mono, fontSize: 10, padding: "3px 10px", borderRadius: 999, background: DCOLORS.bgElevated, color: DCOLORS.inkSoft, letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 600 }}>Duration · {p.duration}</span>
              </div>
              <h3 style={{ fontFamily: DFONTS.display, fontSize: 22, fontWeight: 700, margin: "0 0 8px", color: DCOLORS.ink, letterSpacing: "-0.015em" }}>{p.title}</h3>
              <p style={{ fontSize: 14, color: DCOLORS.inkSoft, lineHeight: 1.6, margin: "0 0 18px", maxWidth: 760 }}>{p.body}</p>
              <div style={{ borderLeft: `2px solid ${DCOLORS.accent}`, paddingLeft: 14, display: "grid", gap: 8 }}>
                {p.phases.map((phase, i) => (
                  <div key={phase} style={{ display: "flex", gap: 12, fontSize: 13, color: DCOLORS.ink }}>
                    <span style={{ fontFamily: DFONTS.mono, fontSize: 10, color: DCOLORS.inkMute, letterSpacing: "0.06em", textTransform: "uppercase", minWidth: 64 }}>Phase {i + 1}</span>
                    <span>{phase}</span>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </Section>
    </div>
  );
}

window.ProtocolsTab = Protocols;
