/* global React, DCOLORS, DFONTS, Section, Sparkbar, TierBadge */

const CATEGORY_DRILL = [
  { name: "Cardiovascular",     score: 32, markers: ["LDL-C", "HDL-C", "ApoB", "Lp(a)", "Triglycerides", "hs-CRP", "Homocysteine"], status: "high" },
  { name: "Metabolic",          score: 58, markers: ["Glucose", "HbA1c", "Insulin", "HOMA-IR", "C-peptide"], status: "med" },
  { name: "Inflammation",       score: 41, markers: ["hs-CRP", "ESR", "Ferritin", "Fibrinogen"], status: "med" },
  { name: "Hormonal · thyroid", score: 64, markers: ["Testosterone", "SHBG", "TSH", "fT3", "fT4"], status: "med" },
  { name: "Nutrients",          score: 78, markers: ["Vitamin D", "B12", "Folate", "Magnesium", "Omega-3 Index"], status: "low" },
  { name: "Liver & Kidney",     score: 82, markers: ["ALT", "AST", "GGT", "Creatinine", "eGFR"], status: "low" },
];

function Categories() {
  const color = (s) => s === "high" ? DCOLORS.critical : s === "med" ? DCOLORS.moderate : DCOLORS.optimal;
  return (
    <div data-screen-label="Dashboard — Categories">
      <Section title="Category Deep Dive" subtitle="Drill into each domain by marker">
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 12 }}>
          {CATEGORY_DRILL.map((c) => (
            <article key={c.name} style={{
              background: DCOLORS.surface, border: `1px solid ${DCOLORS.border}`,
              borderRadius: 10, padding: 20,
              display: "grid", gridTemplateColumns: "200px 1fr auto", alignItems: "center", gap: 24,
            }}>
              <div>
                <div style={{ fontFamily: DFONTS.display, fontSize: 15, fontWeight: 700, color: DCOLORS.ink }}>{c.name}</div>
                <div style={{ fontFamily: DFONTS.mono, fontSize: 11, color: DCOLORS.inkMute, marginTop: 4 }}>{c.markers.length} markers</div>
              </div>
              <div>
                <Sparkbar value={c.score} color={color(c.status)} />
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {c.markers.map((m) => (
                    <span key={m} style={{
                      fontFamily: DFONTS.mono, fontSize: 11,
                      padding: "3px 9px", borderRadius: 999,
                      background: DCOLORS.bgSecondary, color: DCOLORS.inkSoft,
                    }}>{m}</span>
                  ))}
                </div>
              </div>
              <div style={{
                fontFamily: DFONTS.mono, fontSize: 28, fontWeight: 700,
                fontVariantNumeric: "tabular-nums", color: color(c.status),
              }}>{c.score}</div>
            </article>
          ))}
        </div>
      </Section>
    </div>
  );
}

window.Categories = Categories;
