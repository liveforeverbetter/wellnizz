# foreverbetter — Dashboard UI kit

A high-fidelity recreation of the local-first genomic dashboard. Source of truth: `open-source/DESIGN.md` (v2.5) + `open-source/skills/genomic-analysis/templates/genomic-dashboard.html`.

## What's here

- `index.html` — clickable dashboard with tab switching (Overview / Categories / Protocols / Genetic Variants).
- `dashboard-components.jsx` — atoms (`NavBar`, `FindingsCell`, `TierBadge`, `RiskBadge`, `Section`, `Sparkbar`).
- `overview-panel.jsx` — the Overview tab: GLI Hero with Innate Strengths, Category Breakdown grid, Key Insights, Action Plan, Recommended Protocols.
- `categories-panel.jsx` / `protocols-panel.jsx` / `variants-panel.jsx` — the other three tabs (simpler — coverage examples, not full recreations).

## Visual language

- Font stack: Plus Jakarta Sans + JetBrains Mono.
- Brand: coral red `#df1e39` (= `oklch(58% 0.22 22)`); surface white; canvas off-white `#fafaf9`.
- GLI conic ring, risk-bordered cards, tier pills, tabular numerals everywhere.

## Coverage

| Component | Tab | Status |
|---|---|---|
| Sticky pill-tab nav | all | ✅ |
| Findings summary row | Overview | ✅ |
| Hero card (GLI ring + Innate Strengths) | Overview | ✅ |
| Category Breakdown grid | Overview | ✅ |
| Key Insights cards | Overview | ✅ |
| Action Plan ("How … turns DNA into a plan") | Overview | ✅ |
| Action Plan high-priority cards | Overview | ✅ |
| Recommended Protocols (Tier 1/2) | Overview | ✅ |
| Category drill-down | Categories | partial |
| Protocol library | Protocols | partial |
| Polygenic Risk Score grid | Genetic Variants | partial |
