/* @ds-bundle: {"format":4,"namespace":"ForeverbetterDesignSystem_01951c","components":[],"sourceHashes":{"ui_kits/dashboard/categories-panel.jsx":"485fcbea4c11","ui_kits/dashboard/dashboard-components.jsx":"1c90c0bff24b","ui_kits/dashboard/overview-panel.jsx":"fda5d8fc1c85","ui_kits/dashboard/protocols-panel.jsx":"6f544ad1f7df","ui_kits/dashboard/variants-panel.jsx":"6ea374e1e13f","ui_kits/website/components.jsx":"cd01b36fed51","ui_kits/website/dashboard-card.jsx":"c4938155271a","ui_kits/website/sections-panel.jsx":"49d4e5578a2f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ForeverbetterDesignSystem_01951c = window.ForeverbetterDesignSystem_01951c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/dashboard/categories-panel.jsx
try { (() => {
/* global React, DCOLORS, DFONTS, Section, Sparkbar, TierBadge */

const CATEGORY_DRILL = [{
  name: "Cardiovascular",
  score: 32,
  markers: ["LDL-C", "HDL-C", "ApoB", "Lp(a)", "Triglycerides", "hs-CRP", "Homocysteine"],
  status: "high"
}, {
  name: "Metabolic",
  score: 58,
  markers: ["Glucose", "HbA1c", "Insulin", "HOMA-IR", "C-peptide"],
  status: "med"
}, {
  name: "Inflammation",
  score: 41,
  markers: ["hs-CRP", "ESR", "Ferritin", "Fibrinogen"],
  status: "med"
}, {
  name: "Hormonal · thyroid",
  score: 64,
  markers: ["Testosterone", "SHBG", "TSH", "fT3", "fT4"],
  status: "med"
}, {
  name: "Nutrients",
  score: 78,
  markers: ["Vitamin D", "B12", "Folate", "Magnesium", "Omega-3 Index"],
  status: "low"
}, {
  name: "Liver & Kidney",
  score: 82,
  markers: ["ALT", "AST", "GGT", "Creatinine", "eGFR"],
  status: "low"
}];
function Categories() {
  const color = s => s === "high" ? DCOLORS.critical : s === "med" ? DCOLORS.moderate : DCOLORS.optimal;
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Dashboard \u2014 Categories"
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Category Deep Dive",
    subtitle: "Drill into each domain by marker"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr",
      gap: 12
    }
  }, CATEGORY_DRILL.map(c => /*#__PURE__*/React.createElement("article", {
    key: c.name,
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 10,
      padding: 20,
      display: "grid",
      gridTemplateColumns: "200px 1fr auto",
      alignItems: "center",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 15,
      fontWeight: 700,
      color: DCOLORS.ink
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 11,
      color: DCOLORS.inkMute,
      marginTop: 4
    }
  }, c.markers.length, " markers")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Sparkbar, {
    value: c.score,
    color: color(c.status)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6,
      flexWrap: "wrap"
    }
  }, c.markers.map(m => /*#__PURE__*/React.createElement("span", {
    key: m,
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 11,
      padding: "3px 9px",
      borderRadius: 999,
      background: DCOLORS.bgSecondary,
      color: DCOLORS.inkSoft
    }
  }, m)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 28,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: color(c.status)
    }
  }, c.score))))));
}
window.Categories = Categories;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/categories-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/dashboard-components.jsx
try { (() => {
/* global React */
const {
  useState
} = React;
const DCOLORS = {
  bgPrimary: "#fafaf9",
  bgSecondary: "#f3f1ef",
  bgElevated: "#eae6e2",
  surface: "#ffffff",
  ink: "#1a1514",
  inkSoft: "#4a3f3a",
  inkMute: "#7a6e68",
  inkFaint: "#a0948e",
  inverse: "#ffffff",
  border: "#e7e2dd",
  borderStrong: "#c5beb7",
  accent: "#df1e39",
  accentSoft: "rgba(223,30,57,0.10)",
  optimal: "oklch(52% 0.16 145)",
  neutral: "oklch(48% 0.12 248)",
  moderate: "oklch(55% 0.14 72)",
  critical: "oklch(48% 0.20 22)",
  inactive: "#a0948e"
};
const DFONTS = {
  display: '"Plus Jakarta Sans", system-ui, sans-serif',
  body: '"Plus Jakarta Sans", system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace'
};
function NavBar({
  tab,
  onTab
}) {
  const tabs = ["Overview", "Categories", "Protocols", "Genetic Variants"];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 100,
      height: 64,
      background: "rgba(250,250,249,0.82)",
      backdropFilter: "blur(20px)",
      WebkitBackdropFilter: "blur(20px)",
      borderBottom: `1px solid ${DCOLORS.border}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 1200,
      margin: "0 24px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '"DM Sans", system-ui, sans-serif',
      fontSize: 20,
      fontWeight: 700,
      color: DCOLORS.ink,
      letterSpacing: "-0.025em"
    }
  }, "forever", /*#__PURE__*/React.createElement("span", {
    style: {
      color: DCOLORS.accent
    }
  }, "better")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      background: DCOLORS.bgSecondary,
      borderRadius: 999,
      padding: 3
    }
  }, tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => onTab(t),
    style: {
      padding: "10px 18px",
      fontFamily: DFONTS.body,
      fontSize: 13,
      fontWeight: 600,
      borderRadius: 999,
      border: 0,
      cursor: "pointer",
      color: tab === t ? DCOLORS.ink : DCOLORS.inkSoft,
      background: tab === t ? DCOLORS.surface : "transparent",
      boxShadow: tab === t ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
      minHeight: 38
    }
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 32,
      height: 32,
      borderRadius: 999,
      background: DCOLORS.accent,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: DFONTS.body,
      fontSize: 12,
      fontWeight: 700,
      color: "#fff"
    }
  }, "TE")));
}
function Section({
  title,
  subtitle,
  children
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      marginBottom: 56
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 22,
      fontWeight: 700,
      letterSpacing: "-0.025em",
      margin: 0,
      color: DCOLORS.ink
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.body,
      fontSize: 13,
      color: DCOLORS.inkMute,
      fontWeight: 500
    }
  }, subtitle) : null), children);
}
function FindingsCell({
  value,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 8,
      padding: 16,
      textAlign: "center",
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 24,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: DCOLORS.ink,
      lineHeight: 1,
      marginBottom: 6
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.body,
      fontSize: 11,
      color: DCOLORS.inkMute,
      fontWeight: 500,
      lineHeight: 1.4
    }
  }, label));
}
function TierBadge({
  tier
}) {
  const map = {
    1: {
      lbl: "TIER 1 · ESTABLISHED",
      bg: "oklch(52% 0.16 145 / 0.12)",
      fg: "oklch(52% 0.16 145)"
    },
    2: {
      lbl: "TIER 2 · EMERGING",
      bg: "oklch(48% 0.12 248 / 0.12)",
      fg: "oklch(48% 0.12 248)"
    },
    3: {
      lbl: "TIER 3 · INVESTIGATIONAL",
      bg: "rgba(122,110,104,0.15)",
      fg: DCOLORS.inkMute
    }
  };
  const s = map[tier] || map[1];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "3px 10px",
      borderRadius: 999,
      fontFamily: DFONTS.body,
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.06em",
      background: s.bg,
      color: s.fg
    }
  }, s.lbl);
}
function RiskBadge({
  level
}) {
  const map = {
    high: {
      lbl: "HIGH PRIORITY",
      bg: "rgba(223,30,57,0.10)",
      fg: DCOLORS.accent
    },
    med: {
      lbl: "MEDIUM",
      bg: DCOLORS.bgElevated,
      fg: DCOLORS.moderate
    },
    low: {
      lbl: "LOW",
      bg: "oklch(52% 0.16 145 / 0.12)",
      fg: DCOLORS.optimal
    }
  };
  const s = map[level] || map.med;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "3px 10px",
      borderRadius: 999,
      fontFamily: DFONTS.body,
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.05em",
      textTransform: "uppercase",
      background: s.bg,
      color: s.fg
    }
  }, s.lbl);
}
function Sparkbar({
  value,
  max = 100,
  color
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 4,
      background: DCOLORS.bgElevated,
      borderRadius: 2,
      overflow: "hidden",
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      width: `${value / max * 100}%`,
      background: color,
      borderRadius: 2
    }
  }));
}
Object.assign(window, {
  DCOLORS,
  DFONTS,
  NavBar,
  Section,
  FindingsCell,
  TierBadge,
  RiskBadge,
  Sparkbar,
  useState
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/dashboard-components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/overview-panel.jsx
try { (() => {
/* global React, DCOLORS, DFONTS, Section, FindingsCell, TierBadge, RiskBadge, Sparkbar */

// ─── Hero ─────────────────────────────────────────────────────────────
function HeroCard() {
  return /*#__PURE__*/React.createElement("article", {
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 14,
      padding: 32,
      marginBottom: 48,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: -80,
      right: -80,
      width: 260,
      height: 260,
      background: "radial-gradient(circle at center, oklch(58% 0.22 22 / 0.05) 0%, transparent 70%)",
      borderRadius: "50%",
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      position: "absolute",
      top: 20,
      right: 20,
      zIndex: 5,
      display: "flex",
      alignItems: "center",
      gap: 6,
      padding: "10px 16px",
      borderRadius: 999,
      minHeight: 40,
      background: DCOLORS.accent,
      border: 0,
      fontFamily: DFONTS.body,
      fontSize: 13,
      fontWeight: 600,
      color: "#fff",
      cursor: "pointer"
    }
  }, "\u2715 Share"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 32,
      alignItems: "center",
      position: "relative",
      zIndex: 1,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 14,
      minWidth: 200
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 140,
      height: 140
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "140",
    height: "140",
    viewBox: "0 0 120 120",
    style: {
      transform: "rotate(-90deg)",
      display: "block"
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "60",
    cy: "60",
    r: "56",
    fill: "none",
    stroke: DCOLORS.border,
    strokeWidth: "10"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "60",
    cy: "60",
    r: "56",
    fill: "none",
    stroke: DCOLORS.moderate,
    strokeWidth: "10",
    strokeLinecap: "round",
    strokeDasharray: "351.86",
    strokeDashoffset: 351.86 * (1 - 0.46)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 44,
      fontWeight: 700,
      letterSpacing: "-0.04em",
      lineHeight: 1,
      fontVariantNumeric: "tabular-nums",
      color: DCOLORS.ink
    }
  }, "46"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 9.5,
      fontWeight: 600,
      letterSpacing: "0.22em",
      textTransform: "uppercase",
      color: DCOLORS.inkMute,
      marginTop: 4
    }
  }, "GLI"))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.22em",
      textTransform: "uppercase",
      color: DCOLORS.inkMute
    }
  }, "HEALTHSPAN SCORE"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      flexWrap: "wrap",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 22,
      fontWeight: 700,
      letterSpacing: "-0.03em",
      color: DCOLORS.ink,
      lineHeight: 1
    }
  }, "Top 46%"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "3px 10px",
      borderRadius: 999,
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      background: "oklch(55% 0.14 72 / 0.12)",
      color: "oklch(55% 0.14 72)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: "currentColor"
    }
  }), "Moderate")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: DFONTS.body,
      fontSize: 12,
      color: DCOLORS.inkSoft,
      lineHeight: 1.55,
      maxWidth: 280,
      margin: 0,
      textAlign: "center"
    }
  }, "Your genomic profile shows several areas where targeted interventions can make a meaningful difference."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: DCOLORS.inkMute,
      textAlign: "center"
    }
  }, "Focus areas: immune response, eye health, dna repair")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1",
      fontFamily: DFONTS.body,
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: DCOLORS.inkMute
    }
  }, "INNATE STRENGTHS"), [{
    rs: "rs5744168",
    score: 85
  }, {
    rs: "rs2070744",
    score: 85
  }].map(s => /*#__PURE__*/React.createElement("article", {
    key: s.rs,
    style: {
      background: "oklch(58% 0.22 22 / 0.03)",
      border: "1px solid oklch(58% 0.22 22 / 0.1)",
      borderRadius: 8,
      padding: 16,
      minHeight: 120
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      padding: "2px 8px",
      borderRadius: 999,
      marginBottom: 8,
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      background: "oklch(58% 0.22 22 / 0.10)",
      color: DCOLORS.accent
    }
  }, "Innate strength"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.body,
      fontSize: 14,
      fontWeight: 700,
      color: DCOLORS.ink,
      letterSpacing: "-0.01em"
    }
  }, "Protective ", s.rs), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 20,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: DCOLORS.accent
    }
  }, s.score)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      lineHeight: 1.5,
      color: DCOLORS.inkSoft,
      marginBottom: 10
    }
  }, "You have a genetic advantage in protective ", s.rs, ". This means your natural biology supports healthy function in this area."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      padding: "2px 8px",
      borderRadius: 999,
      fontSize: 10,
      fontWeight: 600,
      background: "oklch(55% 0.16 145 / 0.1)",
      color: DCOLORS.optimal
    }
  }, "High Impact"), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: "2px 8px",
      borderRadius: 999,
      fontSize: 10,
      fontWeight: 600,
      background: "oklch(48% 0.12 248 / 0.1)",
      color: DCOLORS.neutral
    }
  }, "Moderate confidence")))))));
}

// ─── Category Breakdown ───────────────────────────────────────────────
const CATEGORIES = [{
  icon: "🌿",
  title: "Genetic Vulnerability",
  score: 39,
  color: DCOLORS.accent,
  meta: "74 markers · 45 flagged"
}, {
  icon: "💊",
  title: "Pharmacological",
  score: 25,
  color: DCOLORS.neutral,
  meta: "74 markers · 28 interactions"
}, {
  icon: "🌙",
  title: "Hereditary",
  score: 30,
  color: DCOLORS.optimal,
  meta: "25 markers · At Risk"
}, {
  icon: "★",
  title: "Personal Traits",
  score: 45,
  color: DCOLORS.accent,
  meta: "38 markers · 7 insights"
}, {
  icon: "🩺",
  title: "Wellness",
  score: 48,
  color: DCOLORS.optimal,
  meta: "80 markers · 14 recs"
}, {
  icon: "🧬",
  title: "Ancestry",
  score: 75,
  color: "#8b5cf6",
  meta: "14 markers · 2 haplogroups"
}];
function CategoryGrid() {
  return /*#__PURE__*/React.createElement(Section, {
    title: "Category Breakdown",
    subtitle: "6 dimensions of your genetic profile"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
      gap: 14
    }
  }, CATEGORIES.map(c => /*#__PURE__*/React.createElement("article", {
    key: c.title,
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 8,
      padding: 18,
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 5,
      marginBottom: 12,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 18,
      background: DCOLORS.bgSecondary
    }
  }, c.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: DCOLORS.ink,
      marginBottom: 6
    }
  }, c.title), /*#__PURE__*/React.createElement(Sparkbar, {
    value: c.score,
    color: c.color
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 18,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: c.color
    }
  }, c.title === "Ancestry" ? `${c.score}%` : c.score), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: DCOLORS.inkMute,
      marginTop: 2
    }
  }, c.meta)))));
}

// ─── Insights ─────────────────────────────────────────────────────────
const INSIGHTS = [{
  title: "Methylation",
  body: "Your methylation is moderate. There is room for optimization.",
  count: 3
}, {
  title: "Immune Response",
  body: "Your immune response is below optimal. Consider the actions below to improve.",
  count: 2
}, {
  title: "Thyroid Function",
  body: "Your thyroid function is below optimal. Consider the actions below to improve.",
  count: 2
}, {
  title: "Eye Health",
  body: "Your eye health is below optimal. Consider the actions below to improve.",
  count: 2
}];
function Insights() {
  return /*#__PURE__*/React.createElement(Section, {
    title: "Key Insights",
    subtitle: "What your data is telling you"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
      gap: 14
    }
  }, INSIGHTS.map(i => /*#__PURE__*/React.createElement("article", {
    key: i.title,
    style: {
      background: DCOLORS.surface,
      borderLeft: `3px solid ${DCOLORS.borderStrong}`,
      borderRadius: "0 8px 8px 0",
      padding: 20,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 15,
      fontWeight: 700,
      color: DCOLORS.ink,
      letterSpacing: "-0.01em",
      marginBottom: 6
    }
  }, i.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      lineHeight: 1.6,
      color: DCOLORS.inkSoft,
      marginBottom: 12
    }
  }, i.body), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: DCOLORS.accent
    }
  }, i.count, " recommended actions \u2192")))));
}

// ─── Action Plan ──────────────────────────────────────────────────────
const ACTIONS = [{
  id: "CHOLESTEROL",
  title: "Cholesterol",
  meta: "PCSK9-mediated LDL receptor recycling",
  body: "PCSK9-mediated LDL receptor recycling",
  steps: ["Consider PCSK9 inhibitor", "Aggressive statin therapy", "Monitor and re-assess in 3–6 months"]
}, {
  id: "LIPID_METABOLISM",
  title: "Lipid Metabolism",
  meta: "APOB and PCSK9 regulation of LDL cholesterol",
  body: "APOB and PCSK9 regulation of LDL cholesterol",
  steps: ["Follow heart-healthy diet", "Consider statin therapy", "Monitor and re-assess in 3–6 months"]
}, {
  id: "CARDIOMYOPATHY_RISK",
  title: "Cardiomyopathy Risk",
  meta: "Genetic variants in sarcomere genes (MYH7, MYBPC3)",
  body: "Genetic variants in sarcomere genes (MYH7, MYBPC3, TNNT2, TNNI3), desmosomal genes (PKP2, DSP, DSG2), and other structural proteins that increase susceptibility.",
  steps: ["Refer to cardiology for echocardiogram", "Serial cardiac monitoring", "Monitor and re-assess in 3–6 months"]
}, {
  id: "CANCER_SUSCEPTIBILITY",
  title: "Cancer Susceptibility",
  meta: "Inherited predisposition to malignancies from germ",
  body: "Inherited predisposition to malignancies from germline pathogenic variants in tumor suppressor genes, oncogenes, and DNA repair genes (e.g., BRCA1/2, TP53, MLH1, APC, CDKN2A).",
  steps: ["Genetic counseling and risk assessment", "Enhanced cancer screening protocol", "Monitor and re-assess in 3–6 months"]
}];
function ActionPlan() {
  return /*#__PURE__*/React.createElement(Section, {
    title: "Your Action Plan",
    subtitle: "Your DNA \u2192 what to do about it"
  }, /*#__PURE__*/React.createElement("article", {
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 14,
      padding: 28,
      marginBottom: 20,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 18,
      fontWeight: 700,
      margin: "0 0 18px",
      color: DCOLORS.ink,
      letterSpacing: "-0.015em"
    }
  }, "How foreverbetter turns your DNA into a plan"), [["Built on your full genetic picture", "Your plan uses your full genetic data across all 6 categories: vulnerability, pharmacogenetics, hereditary risk, traits, wellness, and ancestry. The system looks for patterns across markers."], ["Every step is matched to your genotype", "Each recommendation is actionable, time-bound, and tied to the specific gene variant that triggered it. Every suggestion traces back to a specific gene variant, with evidence citations attached."], ["Prioritized by what matters most", "High priority = drug sensitivities and actionable risks (share with your doctor). Medium priority = daily optimizations you control (diet, sleep, supplementation). Everything is graded by impact and difficulty so you know where to start."]].map(([t, b], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: "grid",
      gridTemplateColumns: "30px 1fr",
      gap: 14,
      marginBottom: 14,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      borderRadius: "50%",
      background: DCOLORS.accent,
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      fontWeight: 700,
      fontFamily: DFONTS.body
    }
  }, i + 1), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: DCOLORS.ink,
      marginBottom: 2
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: DCOLORS.inkSoft,
      lineHeight: 1.55
    }
  }, b))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
      gap: 16
    }
  }, ACTIONS.map(a => /*#__PURE__*/React.createElement("article", {
    key: a.id,
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 8,
      padding: 22,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)"
    }
  }, /*#__PURE__*/React.createElement(RiskBadge, {
    level: "high"
  }), /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 17,
      fontWeight: 700,
      margin: "10px 0 6px",
      color: DCOLORS.ink,
      letterSpacing: "-0.015em"
    }
  }, a.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 11,
      color: DCOLORS.inkMute,
      letterSpacing: "0.03em",
      marginBottom: 10
    }
  }, a.id, " \xB7 ", a.meta), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: DCOLORS.inkSoft,
      lineHeight: 1.55,
      marginBottom: 14
    }
  }, a.body), /*#__PURE__*/React.createElement("ol", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "grid",
      gap: 8
    }
  }, a.steps.map((s, i) => /*#__PURE__*/React.createElement("li", {
    key: s,
    style: {
      display: "flex",
      gap: 10,
      alignItems: "flex-start",
      fontSize: 13,
      color: DCOLORS.ink
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: DCOLORS.accent,
      color: "#fff",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 11,
      fontWeight: 700,
      marginTop: 1
    }
  }, i + 1), /*#__PURE__*/React.createElement("span", null, s))))))));
}

// ─── Protocols ────────────────────────────────────────────────────────
const PROTOCOLS = [{
  tier: 1,
  title: "Core Optimization Protocol",
  impact: "HIGH",
  difficulty: "MODERATE",
  checklist: [["Take methylfolate", true], ["Consider PCSK9 inhibitor", false], ["Cascade family screening", false]]
}, {
  tier: 1,
  title: "Maintenance Protocol",
  impact: "MEDIUM-HIGH",
  difficulty: "MODERATE",
  checklist: [["Take methylfolate", true], ["Consider PCSK9 inhibitor", false], ["Cascade family screening", false]]
}, {
  tier: 2,
  title: "Emerging Add-on (placeholder)",
  impact: "MEDIUM",
  difficulty: "LOW",
  checklist: [["Add cofactor stack", false], ["Re-test at 12 weeks", false]]
}];
function Protocols() {
  return /*#__PURE__*/React.createElement(Section, {
    title: "Recommended Protocols",
    subtitle: "Action plans matched to your genotype"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: DCOLORS.inkSoft,
      lineHeight: 1.6,
      marginBottom: 18
    }
  }, "Protocols are structured multi-week programs built from your genetic results. Each combines your biology with evidence-graded actions split into phases, with milestones and check-ins along the way."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
      gap: 16
    }
  }, PROTOCOLS.map(p => /*#__PURE__*/React.createElement("article", {
    key: p.title,
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 10,
      padding: 22,
      display: "flex",
      flexDirection: "column",
      gap: 12,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)"
    }
  }, /*#__PURE__*/React.createElement(TierBadge, {
    tier: p.tier
  }), /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 18,
      fontWeight: 700,
      margin: 0,
      color: DCOLORS.ink,
      letterSpacing: "-0.015em"
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 10,
      padding: "3px 10px",
      borderRadius: 999,
      background: DCOLORS.bgElevated,
      color: DCOLORS.inkSoft,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      fontWeight: 600
    }
  }, "Impact: ", p.impact), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 10,
      padding: "3px 10px",
      borderRadius: 999,
      background: DCOLORS.bgElevated,
      color: DCOLORS.inkSoft,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      fontWeight: 600
    }
  }, "Difficulty: ", p.difficulty)), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: DCOLORS.border
    }
  }), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "grid",
      gap: 8
    }
  }, p.checklist.map(([s, done]) => /*#__PURE__*/React.createElement("li", {
    key: s,
    style: {
      display: "flex",
      gap: 10,
      fontSize: 13,
      color: DCOLORS.ink,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: "50%",
      border: done ? "0" : `1.5px solid ${DCOLORS.borderStrong}`,
      background: done ? DCOLORS.optimal : "transparent",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 11,
      flexShrink: 0
    }
  }, done ? "✓" : ""), /*#__PURE__*/React.createElement("span", {
    style: {
      color: done ? DCOLORS.inkMute : DCOLORS.ink,
      textDecoration: done ? "none" : "none"
    }
  }, s)))), /*#__PURE__*/React.createElement("button", {
    style: {
      marginTop: "auto",
      padding: "12px 20px",
      borderRadius: 6,
      background: DCOLORS.accent,
      color: "#fff",
      border: 0,
      cursor: "pointer",
      fontFamily: DFONTS.body,
      fontSize: 14,
      fontWeight: 600,
      letterSpacing: "0.01em"
    }
  }, "View Protocol")))));
}
function Overview() {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Dashboard \u2014 Overview"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
      gap: 14,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement(FindingsCell, {
    value: "274",
    label: "Curated Health Markers Analyzed"
  }), /*#__PURE__*/React.createElement(FindingsCell, {
    value: "0",
    label: "Rare Functional Variants (VEP HIGH/MODERATE)"
  }), /*#__PURE__*/React.createElement(FindingsCell, {
    value: "69",
    label: "ClinVar Pathogenic Findings"
  }), /*#__PURE__*/React.createElement(FindingsCell, {
    value: "0",
    label: "CPIC Drug\u2013Gene Interactions"
  })), /*#__PURE__*/React.createElement(HeroCard, null), /*#__PURE__*/React.createElement(CategoryGrid, null), /*#__PURE__*/React.createElement(Insights, null), /*#__PURE__*/React.createElement(ActionPlan, null), /*#__PURE__*/React.createElement(Protocols, null));
}
Object.assign(window, {
  Overview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/overview-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/protocols-panel.jsx
try { (() => {
/* global React, DCOLORS, DFONTS, Section, TierBadge */

const PROTOCOL_LIB = [{
  tier: 1,
  title: "Methylation Optimization",
  impact: "HIGH",
  duration: "12 weeks",
  body: "Targets MTHFR C677T variants with L-methylfolate, B12, B6, and homocysteine retest at week 12.",
  phases: ["Baseline labs", "L-methylfolate 400mcg daily", "Cofactor stack", "Maintenance"]
}, {
  tier: 1,
  title: "ApoB Lowering",
  impact: "HIGH",
  duration: "6 months",
  body: "Nutrition-first approach to lower apolipoprotein B before pharmacological options. Re-tests every 12 weeks.",
  phases: ["Diet shift (saturated fat)", "Soluble fiber + omega-3", "Re-test at 12 weeks", "Physician escalation if needed"]
}, {
  tier: 2,
  title: "Inflammatory Load Reduction",
  impact: "MEDIUM-HIGH",
  duration: "ongoing",
  body: "hs-CRP reduction stack — emerging evidence. Sleep, exercise, omega-3, polyphenol-rich diet.",
  phases: ["Sleep hygiene baseline", "Polyphenol-rich diet", "Resistance training", "Re-test hs-CRP"]
}];
function Protocols() {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Dashboard \u2014 Protocols"
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Protocol Library",
    subtitle: "Evidence-graded, multi-phase programs"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 16
    }
  }, PROTOCOL_LIB.map(p => /*#__PURE__*/React.createElement("article", {
    key: p.title,
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 10,
      padding: 24,
      boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 1px 3px rgba(0,0,0,0.04)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(TierBadge, {
    tier: p.tier
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 10,
      padding: "3px 10px",
      borderRadius: 999,
      background: DCOLORS.bgElevated,
      color: DCOLORS.inkSoft,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      fontWeight: 600
    }
  }, "Impact \xB7 ", p.impact), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 10,
      padding: "3px 10px",
      borderRadius: 999,
      background: DCOLORS.bgElevated,
      color: DCOLORS.inkSoft,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      fontWeight: 600
    }
  }, "Duration \xB7 ", p.duration)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: DFONTS.display,
      fontSize: 22,
      fontWeight: 700,
      margin: "0 0 8px",
      color: DCOLORS.ink,
      letterSpacing: "-0.015em"
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: DCOLORS.inkSoft,
      lineHeight: 1.6,
      margin: "0 0 18px",
      maxWidth: 760
    }
  }, p.body), /*#__PURE__*/React.createElement("div", {
    style: {
      borderLeft: `2px solid ${DCOLORS.accent}`,
      paddingLeft: 14,
      display: "grid",
      gap: 8
    }
  }, p.phases.map((phase, i) => /*#__PURE__*/React.createElement("div", {
    key: phase,
    style: {
      display: "flex",
      gap: 12,
      fontSize: 13,
      color: DCOLORS.ink
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 10,
      color: DCOLORS.inkMute,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      minWidth: 64
    }
  }, "Phase ", i + 1), /*#__PURE__*/React.createElement("span", null, phase)))))))));
}
window.ProtocolsTab = Protocols;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/protocols-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/variants-panel.jsx
try { (() => {
/* global React, DCOLORS, DFONTS, Section */

const PRS = [{
  lbl: "Coronary artery disease",
  pct: 11,
  level: "LOWER THAN AVERAGE",
  icon: "✓"
}, {
  lbl: "Type 2 diabetes",
  pct: 10,
  level: "LOWER THAN AVERAGE",
  icon: "✓"
}, {
  lbl: "Breast cancer",
  pct: 12,
  level: "LOWER THAN AVERAGE",
  icon: "✓"
}, {
  lbl: "Alzheimer's disease",
  pct: 13,
  level: "LOWER THAN AVERAGE",
  icon: "✓"
}, {
  lbl: "VO₂max",
  pct: 27,
  level: "AVERAGE",
  icon: "—"
}, {
  lbl: "Grip strength",
  pct: 9,
  level: "LOWER",
  icon: "↓"
}, {
  lbl: "Bone mineral density",
  pct: 8,
  level: "LOWER",
  icon: "↓"
}, {
  lbl: "HDL cholesterol",
  pct: 13,
  level: "LOWER",
  icon: "↓"
}, {
  lbl: "LDL cholesterol",
  pct: 58,
  level: "AVERAGE",
  icon: "—"
}, {
  lbl: "Triglycerides",
  pct: 23,
  level: "AVERAGE",
  icon: "—"
}];
function Variants() {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Dashboard \u2014 Genetic Variants"
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Polygenic Risk Scores",
    subtitle: "Aggregate genetic risk across multiple variants for common complex diseases"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
      gap: 14
    }
  }, PRS.map(p => /*#__PURE__*/React.createElement("article", {
    key: p.lbl,
    style: {
      background: DCOLORS.surface,
      border: `1px solid ${DCOLORS.border}`,
      borderRadius: 10,
      padding: 18,
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      minHeight: 200
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: DFONTS.body,
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.06em",
      padding: "3px 9px",
      borderRadius: 999,
      background: p.level.includes("LOWER") ? "oklch(48% 0.12 248 / 0.10)" : DCOLORS.bgSecondary,
      color: p.level.includes("LOWER") ? DCOLORS.neutral : DCOLORS.inkSoft
    }
  }, p.level), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 5,
      background: p.icon === "✓" ? DCOLORS.optimal : p.icon === "↓" ? DCOLORS.inkSoft : "transparent",
      border: p.icon === "—" ? `1.5px solid ${DCOLORS.border}` : "0",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 13
    }
  }, p.icon === "—" ? "" : p.icon)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: DCOLORS.inkSoft,
      lineHeight: 1.5,
      margin: "0 0 12px"
    }
  }, "Your polygenic profile for ", p.lbl.toLowerCase(), " is ", p.level.toLowerCase(), "."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: DFONTS.mono,
      fontSize: 12,
      color: DCOLORS.ink,
      fontWeight: 600
    }
  }, "Percentile: ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: DCOLORS.accent,
      fontVariantNumeric: "tabular-nums"
    }
  }, p.pct, "%")))))));
}
window.Variants = Variants;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/variants-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components.jsx
try { (() => {
/* global React */
const {
  useState
} = React;
const COLORS = {
  brand: "#df1e39",
  brandSoft: "#fce8eb",
  brandTint: "#fdf3f5",
  canvas: "#f6f3ee",
  paper: "#fbf9f5",
  ink: "#0e0e0e",
  inkSoft: "#3a3a38",
  inkMute: "#7a7770",
  line: "#e6e1d8",
  lineSoft: "#efeae0",
  good: "#1e7a52",
  night: "#0a0806"
};
const FONTS = {
  display: '"Fraunces", "Georgia", serif',
  sans: '"DM Sans", system-ui, sans-serif',
  mono: '"DM Mono", ui-monospace, monospace'
};
function Logo({
  light = false
}) {
  const fg = light ? "#fff" : COLORS.ink;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '"DM Sans", system-ui, sans-serif',
      fontSize: 20,
      fontWeight: 700,
      color: fg,
      letterSpacing: "-0.025em",
      lineHeight: 1,
      whiteSpace: "nowrap"
    }
  }, "forever", /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "better"));
}
function Btn({
  children,
  onClick,
  variant = "primary",
  full = false,
  href
}) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 48,
    width: full ? "100%" : undefined,
    border: "1.5px solid transparent",
    borderRadius: 999,
    padding: "0 24px",
    fontFamily: FONTS.sans,
    fontSize: 14,
    fontWeight: 600,
    textDecoration: "none",
    whiteSpace: "nowrap",
    cursor: "pointer",
    letterSpacing: 0.2
  };
  const variants = {
    primary: {
      background: COLORS.brand,
      borderColor: COLORS.brand,
      color: "#fff"
    },
    dark: {
      background: COLORS.ink,
      borderColor: COLORS.ink,
      color: "#fff"
    },
    ghost: {
      background: "transparent",
      borderColor: COLORS.ink,
      color: COLORS.ink
    },
    glass: {
      background: "rgba(255,255,255,0.12)",
      borderColor: "rgba(255,255,255,0.28)",
      color: "#fff",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)"
    }
  };
  const Tag = href ? "a" : "button";
  return /*#__PURE__*/React.createElement(Tag, {
    href: href,
    onClick: onClick,
    style: {
      ...base,
      ...variants[variant]
    }
  }, children);
}
function Eyebrow({
  children,
  light = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      color: light ? "rgba(255,255,255,0.5)" : COLORS.inkMute,
      letterSpacing: 2,
      textTransform: "uppercase"
    }
  }, children);
}
function Stat({
  value,
  label,
  light = false
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.display,
      fontSize: 28,
      fontWeight: 700,
      color: light ? "#fff" : COLORS.ink,
      lineHeight: 1
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: light ? "rgba(255,255,255,0.5)" : COLORS.inkMute,
      letterSpacing: 1,
      textTransform: "uppercase",
      marginTop: 4
    }
  }, label));
}
function Check() {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-grid",
      placeItems: "center",
      width: 22,
      height: 22,
      borderRadius: 999,
      background: COLORS.brand,
      color: "#fff",
      flexShrink: 0,
      fontSize: 11,
      fontWeight: 700
    }
  }, "+");
}
Object.assign(window, {
  COLORS,
  FONTS,
  Logo,
  Btn,
  Eyebrow,
  Stat,
  Check,
  useState
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/dashboard-card.jsx
try { (() => {
/* global React, COLORS, FONTS */

function DashboardCard() {
  const rows = [{
    code: "LDL-C",
    label: "Cholesterol",
    value: "92 mg/dL",
    st: true
  }, {
    code: "HBA1C",
    label: "Glycemic",
    value: "5.2%",
    st: true
  }, {
    code: "APOB",
    label: "ApoB",
    value: "118 mg/dL",
    st: false
  }, {
    code: "HSCRP",
    label: "Inflammation",
    value: "2.8 mg/L",
    st: null
  }, {
    code: "VITD",
    label: "Vitamin D",
    value: "47 ng/mL",
    st: true
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#111",
      border: "1px solid rgba(255,255,255,0.09)",
      borderRadius: 16,
      padding: 28,
      boxShadow: "0 24px 72px rgba(10,8,6,.22)",
      color: "#fff",
      width: "100%",
      maxWidth: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: "#a8a59c",
      letterSpacing: 1.4,
      textTransform: "uppercase"
    }
  }, "Healthspan score"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.display,
      fontSize: 72,
      fontWeight: 700,
      lineHeight: 1,
      marginTop: 4
    }
  }, "74")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 4,
      height: 48,
      borderBottom: "1px solid rgba(255,255,255,0.08)",
      paddingBottom: 4
    }
  }, [62, 58, 65, 68, 72, 71, 74].map((h, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 10,
      height: `${h}%`,
      background: i === 6 ? COLORS.brand : "rgba(255,255,255,0.18)",
      borderRadius: "3px 3px 0 0",
      display: "block"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 9,
      color: COLORS.brand,
      letterSpacing: 1,
      marginTop: 6,
      textAlign: "right"
    }
  }, "+6 vs. 2025 baseline"))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: "rgba(255,255,255,0.07)",
      marginBottom: 16
    }
  }), rows.map(({
    code,
    label,
    value,
    st
  }, i) => /*#__PURE__*/React.createElement("div", {
    key: code,
    style: {
      display: "grid",
      gridTemplateColumns: "52px 1fr auto 10px",
      gap: 10,
      padding: "9px 0",
      borderTop: i === 0 ? "none" : "1px solid rgba(255,255,255,0.06)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 9,
      color: "#a8a59c",
      letterSpacing: 1.2,
      textTransform: "uppercase"
    }
  }, code), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.sans,
      fontSize: 13,
      color: "rgba(255,255,255,0.82)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 12,
      color: "#fff"
    }
  }, value), st === null ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 999,
      background: "#c98a1d",
      display: "inline-block"
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 999,
      background: st ? COLORS.good : COLORS.brand,
      display: "inline-block"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      background: "linear-gradient(135deg, rgba(223,30,57,0.18) 0%, rgba(223,30,57,0.06) 100%)",
      border: "1px solid rgba(223,30,57,0.28)",
      borderRadius: 10,
      padding: "12px 16px",
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: COLORS.brand,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: COLORS.brand,
      letterSpacing: 0.8,
      textTransform: "uppercase"
    }
  }, "Top action"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.sans,
      fontSize: 13,
      color: "rgba(255,255,255,0.88)",
      marginTop: 2
    }
  }, "Lower ApoB \u2014 nutrition first"))));
}
window.DashboardCard = DashboardCard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/dashboard-card.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/sections-panel.jsx
try { (() => {
/* global React, COLORS, FONTS, Logo, Btn, Eyebrow, Stat, Check, DashboardCard, useState */

const CONTENT_FRAME = {
  maxWidth: 1440,
  margin: "0 auto"
};
const SECTION_PAD = {
  padding: "clamp(80px,10vw,128px) clamp(20px,5vw,64px)"
};
const H2 = {
  fontFamily: FONTS.display,
  fontSize: "clamp(40px,5vw,64px)",
  fontWeight: 700,
  lineHeight: 1.05,
  letterSpacing: -1,
  margin: 0,
  color: COLORS.ink
};

// ─── Nav ─────────────────────────────────────────────────────────────
function Nav({
  onCheckout
}) {
  const links = [["What we test", "#what-we-test"], ["How it works", "#how-it-works"], ["Pricing", "#membership"], ["FAQ", "#faq"]];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 50,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24,
      padding: "0 clamp(20px,4vw,56px)",
      height: 68,
      background: "rgba(246,243,238,0.90)",
      backdropFilter: "blur(20px) saturate(160%)",
      WebkitBackdropFilter: "blur(20px) saturate(160%)",
      borderBottom: `1px solid ${COLORS.line}`
    }
  }, /*#__PURE__*/React.createElement(Logo, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 32,
      fontSize: 14,
      fontWeight: 500
    }
  }, links.map(([label, href]) => /*#__PURE__*/React.createElement("a", {
    key: label,
    href: href,
    style: {
      color: COLORS.inkSoft,
      textDecoration: "none"
    }
  }, label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("a", {
    style: {
      fontSize: 14,
      color: COLORS.inkMute,
      textDecoration: "none"
    }
  }, "Sign in"), /*#__PURE__*/React.createElement(Btn, {
    variant: "dark",
    onClick: onCheckout
  }, "Become a Member")));
}

// ─── Hero ────────────────────────────────────────────────────────────
function Hero({
  onCheckout
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      minHeight: "100dvh",
      overflow: "hidden",
      background: COLORS.night
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(135deg, #2a1f1a 0%, #4a3328 35%, #6d4b35 70%, #2a1f1a 100%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(100deg, rgba(10,8,6,0.88) 0%, rgba(10,8,6,0.70) 48%, rgba(10,8,6,0.48) 100%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 1,
      ...CONTENT_FRAME,
      minHeight: "100dvh",
      padding: "clamp(80px,10vw,120px) clamp(20px,5vw,64px) clamp(64px,8vw,96px)",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 460px), 1fr))",
      gap: 64,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    light: true
  }, "Europe's longevity membership"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: FONTS.display,
      fontSize: "clamp(40px,4.5vw,58px)",
      fontWeight: 700,
      lineHeight: 1.08,
      letterSpacing: -1,
      color: "#fff",
      margin: "20px 0 24px"
    }
  }, "Know what your", /*#__PURE__*/React.createElement("br", null), "biology is doing,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "every year.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 18,
      lineHeight: 1.6,
      color: "rgba(255,255,255,0.72)",
      maxWidth: 460,
      margin: "0 0 36px"
    }
  }, "Annual longevity blood testing for Europe. 100+ biomarkers in a private EU-hosted dashboard with a protocol you can act on."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      marginBottom: 48
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "primary",
    onClick: onCheckout
  }, "Become a Member"), /*#__PURE__*/React.createElement(Btn, {
    variant: "glass",
    href: "#how-it-works"
  }, "See how it works")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, auto)",
      borderTop: "1px solid rgba(255,255,255,0.14)",
      paddingTop: 24,
      width: "fit-content"
    }
  }, [["100+", "Biomarkers"], ["EUR 199", "Per year"], ["EU", "Data hosted"]].map(([s, l], i) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      paddingRight: i < 2 ? 32 : 0,
      paddingLeft: i > 0 ? 32 : 0,
      borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.14)" : "none"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: s,
    label: l,
    light: true
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(DashboardCard, null))));
}

// ─── Trust strip ─────────────────────────────────────────────────────
function TrustStrip() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#111",
      borderBottom: "1px solid rgba(255,255,255,0.07)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      padding: "32px clamp(20px,5vw,64px)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 24,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    light: true
  }, "Built on peer-reviewed science"), ["ClinVar / NCBI", "CPIC Guidelines", "Lopez-Otin Hallmarks", "ESC 2024", "GDPR Art. 9"].map(item => /*#__PURE__*/React.createElement("span", {
    key: item,
    style: {
      fontFamily: FONTS.display,
      fontSize: 18,
      fontWeight: 600,
      color: "rgba(255,255,255,0.48)",
      whiteSpace: "nowrap"
    }
  }, item))));
}

// ─── Steps ───────────────────────────────────────────────────────────
const STEPS = [{
  n: "01",
  tag: "30 minutes",
  title: "Take the test",
  body: "One fasted morning draw at a partner lab. We send the prep checklist, order form, and exact instructions before you arrive."
}, {
  n: "02",
  tag: "5–7 days",
  title: "Get your results",
  body: "Results are normalised, scored, and loaded into your private EU-hosted dashboard with explanations, trends, and raw data export."
}, {
  n: "03",
  tag: "Live call",
  title: "Review the signal",
  body: "A direct walkthrough of your findings before you change anything. What matters, what to watch, and what to escalate to a physician."
}, {
  n: "04",
  tag: "Ongoing",
  title: "Act on your plan",
  body: "Four to six ranked actions across nutrition, training, supplements, and physician follow-up. Retest yearly and track the trajectory."
}];
function Steps() {
  return /*#__PURE__*/React.createElement("section", {
    id: "how-it-works",
    style: {
      background: COLORS.canvas
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      padding: "clamp(72px,9vw,112px) clamp(20px,5vw,64px) clamp(48px,5vw,64px)"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H2,
      fontSize: "clamp(44px,5.5vw,72px)"
    }
  }, "From draw to dashboard,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "in under two weeks.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 18,
      color: COLORS.inkSoft,
      lineHeight: 1.6,
      marginTop: 20,
      maxWidth: 580
    }
  }, "We handle lab logistics, data normalisation, and EU compliance. You show up for the draw, then use the dashboard to make the next year measurable.")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: `1px solid ${COLORS.line}`,
      borderBottom: `1px solid ${COLORS.line}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)"
    }
  }, STEPS.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: {
      padding: "18px clamp(16px,2.5vw,32px)",
      borderLeft: i > 0 ? `1px solid ${COLORS.line}` : "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      color: COLORS.brand,
      letterSpacing: 1.6
    }
  }, s.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: COLORS.inkSoft,
      marginTop: 4
    }
  }, s.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: COLORS.inkMute,
      letterSpacing: 0.8,
      marginTop: 2
    }
  }, s.tag))))), STEPS.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))",
      borderTop: `1px solid ${COLORS.line}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "clamp(56px,7vw,96px) clamp(32px,5vw,80px)",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      background: i % 2 === 0 ? COLORS.canvas : COLORS.paper,
      minHeight: 500,
      order: i % 2 === 0 ? 0 : 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.display,
      fontSize: "clamp(72px,9vw,120px)",
      fontWeight: 300,
      lineHeight: 1,
      color: COLORS.brandSoft,
      marginBottom: -4
    }
  }, s.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      color: COLORS.inkMute,
      letterSpacing: 1.4,
      textTransform: "uppercase",
      marginBottom: 14
    }
  }, s.tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: FONTS.display,
      fontSize: "clamp(32px,4vw,52px)",
      fontWeight: 700,
      lineHeight: 1.08,
      margin: "0 0 20px",
      color: COLORS.ink
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      lineHeight: 1.65,
      color: COLORS.inkSoft,
      margin: 0,
      maxWidth: 460
    }
  }, s.body)), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 500,
      background: `linear-gradient(135deg, ${["#2b1e16", "#33291f", "#3a2e25", "#2e2820"][i]} 0%, #1a120c 100%)`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "rgba(255,255,255,0.36)",
      fontFamily: FONTS.mono,
      fontSize: 11,
      letterSpacing: 1.5,
      textTransform: "uppercase"
    }
  }, "[ photo placeholder \xB7 ", s.title.toLowerCase(), " ]"))));
}

// ─── Bento ───────────────────────────────────────────────────────────
const STANDARD = [{
  code: "01",
  name: "Cardiovascular",
  markers: ["LDL-C", "HDL-C", "ApoB", "Lp(a)", "Triglycerides", "hs-CRP", "Homocysteine"]
}, {
  code: "02",
  name: "Metabolic",
  markers: ["Glucose", "HbA1c", "Insulin", "HOMA-IR", "C-peptide"]
}, {
  code: "03",
  name: "Hormonal",
  markers: ["Testosterone", "SHBG", "DHEA-S", "Cortisol", "Estradiol", "TSH", "fT3", "fT4"]
}, {
  code: "04",
  name: "Inflammation",
  markers: ["hs-CRP", "ESR", "Ferritin", "Fibrinogen", "IL-6", "WBC diff"]
}, {
  code: "05",
  name: "Liver and Kidney",
  markers: ["ALT", "AST", "GGT", "Albumin", "Creatinine", "eGFR", "Cystatin C"]
}, {
  code: "06",
  name: "Nutrients",
  markers: ["Vitamin D", "B12", "Folate", "Magnesium", "Zinc", "Selenium", "Omega-3 Index"]
}, {
  code: "07",
  name: "Hematology",
  markers: ["CBC", "Hgb", "Hct", "MCV", "Platelets", "Reticulocytes"]
}, {
  code: "09",
  name: "Musculoskeletal",
  markers: ["Calcium", "Phosphate", "ALP", "PTH", "Uric Acid", "Creatine Kinase", "Vitamin K2"]
}, {
  code: "10",
  name: "Digestive",
  markers: ["Calprotectin", "Zonulin", "H. pylori Ab", "Secretory IgA", "Lipase", "Amylase"]
}];
const WGS = {
  code: "08",
  name: "Optional WGS",
  markers: ["Existing VCF", "GLI score", "ClinVar", "CPIC", "Aging hallmarks"]
};
function Bento({
  onCheckout
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "what-we-test",
    style: {
      ...SECTION_PAD,
      background: COLORS.paper,
      borderTop: `1px solid ${COLORS.line}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: CONTENT_FRAME
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))",
      gap: 64,
      marginBottom: 64,
      alignItems: "end"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: H2
  }, "The annual panel for people", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "who already track everything else.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: COLORS.inkSoft,
      lineHeight: 1.65,
      maxWidth: 520,
      margin: 0
    }
  }, "Sleep, HRV, and training data are useful. Bloodwork shows the biology underneath. We group the panel by system so you can see what changed, what matters, and what needs follow-up.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 14
    }
  }, STANDARD.map(sys => /*#__PURE__*/React.createElement("article", {
    key: sys.code,
    style: {
      background: COLORS.canvas,
      border: `1px solid ${COLORS.line}`,
      borderRadius: 12,
      padding: "22px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      letterSpacing: 1.4,
      color: COLORS.inkMute
    }
  }, sys.code), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: COLORS.inkMute
    }
  }, sys.markers.length, " markers")), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: FONTS.display,
      fontSize: 22,
      fontWeight: 700,
      lineHeight: 1.05,
      margin: "0 0 12px",
      color: COLORS.ink
    }
  }, sys.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      letterSpacing: 0.3,
      lineHeight: 1.9,
      color: COLORS.inkSoft
    }
  }, sys.markers.slice(0, 4).map(m => /*#__PURE__*/React.createElement("div", {
    key: m
  }, "- ", m)), sys.markers.length > 4 && /*#__PURE__*/React.createElement("div", {
    style: {
      color: COLORS.inkMute
    }
  }, "+", sys.markers.length - 4, " more")))), /*#__PURE__*/React.createElement("article", {
    style: {
      gridColumn: "1 / -1",
      background: COLORS.ink,
      border: `1px solid ${COLORS.ink}`,
      borderRadius: 12,
      padding: "28px 32px",
      display: "grid",
      gridTemplateColumns: "1fr auto",
      gap: 24,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      letterSpacing: 1.4,
      color: "#a8a59c"
    }
  }, WGS.code), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: COLORS.brand,
      letterSpacing: 0.8,
      textTransform: "uppercase"
    }
  }, "Optional add-on")), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: FONTS.display,
      fontSize: 28,
      fontWeight: 700,
      color: "#fff",
      margin: "0 0 10px"
    }
  }, WGS.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      lineHeight: 1.9,
      color: "#a8a59c",
      display: "flex",
      gap: 24,
      flexWrap: "wrap"
    }
  }, WGS.markers.map(m => /*#__PURE__*/React.createElement("span", {
    key: m
  }, "- ", m)))), /*#__PURE__*/React.createElement(Btn, {
    variant: "primary",
    onClick: onCheckout
  }, "Add genomics")))));
}

// ─── Pricing ─────────────────────────────────────────────────────────
const MEMBERSHIP = [{
  name: "Annual biomarker baseline",
  status: "included"
}, {
  name: "Private healthspan dashboard",
  status: "included"
}, {
  name: "Results walkthrough",
  status: "included"
}, {
  name: "Personalised protocol",
  status: "included"
}, {
  name: "Raw-data export",
  status: "included"
}, {
  name: "Annual retest path",
  status: "included"
}, {
  name: "Optional genomics",
  status: "later"
}, {
  name: "Specialist add-ons",
  status: "later"
}];
function Pricing({
  onCheckout
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "membership",
    style: {
      background: COLORS.night,
      color: "#fff",
      padding: "clamp(80px,10vw,128px) clamp(20px,5vw,64px)",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: -160,
      right: -160,
      width: 600,
      height: 600,
      borderRadius: 999,
      background: COLORS.brand,
      opacity: 0.10,
      filter: "blur(120px)",
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: -200,
      left: -160,
      width: 600,
      height: 600,
      borderRadius: 999,
      background: COLORS.brand,
      opacity: 0.07,
      filter: "blur(140px)",
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      position: "relative",
      zIndex: 1,
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))",
      gap: 80,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H2,
      color: "#fff",
      fontSize: "clamp(44px,6vw,80px)"
    }
  }, "Build your first", /*#__PURE__*/React.createElement("br", null), "European healthspan", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "baseline.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 18,
      color: "rgba(255,255,255,0.66)",
      lineHeight: 1.65,
      marginTop: 28,
      maxWidth: 480
    }
  }, "Annual biomarkers, EU-hosted data controls, and a protocol built around your actual numbers."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 40
    }
  }, MEMBERSHIP.map(item => /*#__PURE__*/React.createElement("div", {
    key: item.name,
    style: {
      display: "grid",
      gridTemplateColumns: "22px 1fr auto",
      gap: 12,
      padding: "12px 0",
      borderBottom: "1px solid rgba(255,255,255,0.07)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Check, null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "rgba(255,255,255,0.90)"
    }
  }, item.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      color: item.status === "included" ? COLORS.good : "rgba(255,255,255,0.32)",
      textAlign: "right"
    }
  }, item.status))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      borderRadius: 20,
      border: "1px solid rgba(255,255,255,0.18)",
      background: "linear-gradient(135deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.06) 100%)",
      backdropFilter: "blur(32px) saturate(160%) contrast(1.04)",
      WebkitBackdropFilter: "blur(32px) saturate(160%) contrast(1.04)",
      boxShadow: "inset 0 1px 0 rgba(255,255,255,0.32), inset 0 -1px 0 rgba(255,255,255,0.08), 0 32px 80px rgba(0,0,0,0.36)",
      padding: 40,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 1,
      borderRadius: 19,
      border: "1px solid rgba(255,255,255,0.10)",
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 11,
      color: COLORS.brand,
      letterSpacing: 1.6,
      textTransform: "uppercase",
      marginBottom: 16
    }
  }, "Core membership"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 10,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.display,
      fontSize: "clamp(64px,8vw,96px)",
      fontWeight: 700,
      lineHeight: 0.95,
      color: "#fff"
    }
  }, "EUR 199"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 14,
      color: "rgba(255,255,255,0.50)"
    }
  }, "/year")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: "rgba(255,255,255,0.56)",
      marginBottom: 32,
      lineHeight: 1.5
    }
  }, "Auto-renews at the same price. Cancel any time."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 10,
      marginBottom: 32
    }
  }, ["100+ biomarker target panel", "Private EU-hosted dashboard", "Personalised ranked protocol", "Raw-data export", "Results walkthrough"].map(f => /*#__PURE__*/React.createElement("div", {
    key: f,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontSize: 14,
      color: "rgba(255,255,255,0.82)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand,
      fontWeight: 700,
      flexShrink: 0
    }
  }, "+"), f))), /*#__PURE__*/React.createElement(Btn, {
    variant: "primary",
    full: true,
    onClick: onCheckout
  }, "Become a Member"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: "rgba(255,255,255,0.36)",
      letterSpacing: 1,
      textAlign: "center",
      textTransform: "uppercase"
    }
  }, "14-day money-back \xB7 One-click cancel"))));
}

// ─── FAQ ─────────────────────────────────────────────────────────────
const FAQS = [{
  q: "Is this a medical service?",
  a: "No. foreverbetter is a wellness and lifestyle insights service. It helps you understand patterns in biomarker and optional genomic data, but it does not diagnose, prescribe, or replace a physician."
}, {
  q: "Who is this for?",
  a: "Health-literate Europeans who already train, track sleep, or collect lab results, and want a yearly baseline with clear priorities instead of scattered PDFs and generic advice."
}, {
  q: "Where is my data stored?",
  a: "The product is built around EU data residency, explicit consent for special-category health and genetic data, and member-controlled export and deletion."
}, {
  q: "Do I need whole-genome sequencing?",
  a: "No. The core product is biomarker-first. Genomic interpretation is an optional add-on, not a requirement."
}, {
  q: "Can I cancel?",
  a: "Yes. The membership is annual and can be cancelled before renewal. No long-term commitment is required beyond the current paid year."
}];
function Faq() {
  return /*#__PURE__*/React.createElement("section", {
    id: "faq",
    style: {
      ...SECTION_PAD,
      background: COLORS.canvas
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 480px), 1fr))",
      gap: 96,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 88
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H2,
      fontSize: "clamp(36px,4.5vw,56px)"
    }
  }, "Questions we get,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "honestly answered.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      color: COLORS.inkSoft,
      lineHeight: 1.65,
      marginTop: 20
    }
  }, "Still curious? Email", " ", /*#__PURE__*/React.createElement("a", {
    style: {
      color: COLORS.brand,
      fontFamily: FONTS.mono,
      fontSize: 13
    }
  }, "hello@foreverbetter.com"), " ", "\u2014 a founder reads every message.")), /*#__PURE__*/React.createElement("div", null, FAQS.map((faq, i) => /*#__PURE__*/React.createElement("details", {
    key: faq.q,
    open: i === 0,
    style: {
      borderTop: i === 0 ? `1.5px solid ${COLORS.ink}` : "none",
      borderBottom: `1px solid ${COLORS.line}`,
      padding: "22px 0"
    }
  }, /*#__PURE__*/React.createElement("summary", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      cursor: "pointer",
      listStyle: "none",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.display,
      fontSize: 22,
      fontWeight: 700,
      lineHeight: 1.2,
      color: COLORS.ink
    }
  }, faq.q), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 18,
      color: COLORS.brand,
      flexShrink: 0
    }
  }, "+")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.65,
      color: COLORS.inkSoft,
      margin: "14px 0 0",
      maxWidth: 640
    }
  }, faq.a))))));
}

// ─── Footer ──────────────────────────────────────────────────────────
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: COLORS.paper,
      color: COLORS.ink
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: COLORS.canvas,
      borderTop: `1px solid ${COLORS.line}`,
      borderBottom: `1px solid ${COLORS.line}`,
      padding: "32px clamp(20px,5vw,64px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 220px), 1fr))",
      gap: 32,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLORS.brand
    }
  }, "Medical disclaimer")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: COLORS.inkSoft,
      lineHeight: 1.7,
      maxWidth: 860,
      margin: 0
    }
  }, "foreverbetter is a wellness and lifestyle service, not a medical service. The biomarker analysis, healthspan score, genomic interpretation, and protocol recommendations are informational only. They do not constitute medical advice, diagnosis, treatment, or prescription. Always consult a qualified physician before changing medication, diet, supplementation, or training."))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "56px clamp(20px,5vw,64px) 28px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...CONTENT_FRAME,
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 180px), 1fr))",
      gap: 40,
      marginBottom: 48
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Logo, null), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: COLORS.inkSoft,
      marginTop: 14,
      lineHeight: 1.65,
      maxWidth: 260
    }
  }, "Annual biomarker readouts, evidence-backed protocols, and optional genomic context. Portugal launch, Europe expansion.")), [["Product", ["How it works", "What we test", "Membership", "Pricing"]], ["Company", ["About", "Blog", "Press", "Careers", "Contact"]], ["Trust", ["Privacy", "GDPR consent", "Sub-processors", "Disclaimers"]], ["Available in", ["Portugal — live", "Spain — next", "Germany — planned", "Netherlands — planned"]]].map(([heading, items]) => /*#__PURE__*/React.createElement("div", {
    key: heading
  }, /*#__PURE__*/React.createElement(Eyebrow, null, heading), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, items.map(item => /*#__PURE__*/React.createElement("div", {
    key: item,
    style: {
      fontSize: 13,
      color: COLORS.ink,
      padding: "5px 0"
    }
  }, item))))))));
}

// ─── Checkout modal ──────────────────────────────────────────────────
function CheckoutSheet({
  open,
  onClose
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(10,8,6,0.72)",
      backdropFilter: "blur(8px)",
      WebkitBackdropFilter: "blur(8px)",
      zIndex: 100,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: COLORS.paper,
      border: `1px solid ${COLORS.line}`,
      borderRadius: 14,
      maxWidth: 480,
      width: "100%",
      padding: 36,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      position: "absolute",
      top: 14,
      right: 14,
      background: "transparent",
      border: 0,
      fontSize: 22,
      color: COLORS.inkMute,
      cursor: "pointer",
      lineHeight: 1
    }
  }, "\xD7"), /*#__PURE__*/React.createElement(Eyebrow, null, "Checkout \xB7 Step 1 of 2"), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H2,
      fontSize: 32,
      margin: "12px 0 6px"
    }
  }, "Founding membership"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: COLORS.inkSoft,
      margin: "0 0 24px"
    }
  }, "You're joining the Portugal founding cohort."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 12,
      marginBottom: 24
    }
  }, [["Annual biomarker baseline", "EUR 199"], ["Optional genomics", "+ EUR 49"], ["Lab fees (paid to lab)", "EUR 280–520"]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 0",
      borderBottom: `1px solid ${COLORS.line}`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: COLORS.ink
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: FONTS.mono,
      fontSize: 13,
      color: COLORS.inkSoft
    }
  }, v)))), /*#__PURE__*/React.createElement(Btn, {
    variant: "primary",
    full: true
  }, "Continue to payment"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      fontFamily: FONTS.mono,
      fontSize: 10,
      color: COLORS.inkMute,
      letterSpacing: 1,
      textAlign: "center",
      textTransform: "uppercase"
    }
  }, "Stripe \xB7 EU hosted \xB7 14-day money-back")));
}
Object.assign(window, {
  Nav,
  Hero,
  TrustStrip,
  Steps,
  Bento,
  Pricing,
  Faq,
  Footer,
  CheckoutSheet
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/sections-panel.jsx", error: String((e && e.message) || e) }); }

})();
